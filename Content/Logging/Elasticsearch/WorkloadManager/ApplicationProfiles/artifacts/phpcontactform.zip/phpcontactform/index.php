<?php

ini_set("display_errors", 1); 

if(isset($_POST) && !empty($_POST)) { 
	              
	if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['message'])) { 
		$name     = $_POST['name'];
		$email    = $_POST['email']; 
		$message = $_POST['message'];     
		error_log("Entered value for Username: ".$name." and Email:". $email ." and Message:". $message); 
		header('Location: index.php');      
	} else {
		error_log("Please enter name, email and message.");
	}
}
?> 
<html>

<head>
	<title>Simple Contact Form</title>
	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>

	<div id="page-wrap">

		<h1 align="center">Simple Contact Form</h1><br /><br />
				
		<div id="contact-area">
			
			<form method="post" action="" name="regForm">
				<label for="Name">Name:</label>
				<input type="text" name="name" id="Name" /> 
	
				<label for="Email">Email:</label>
				<input type="text" name="email" id="Email" />
				
				<label for="Message">Message:</label><br />
				<textarea name="message" rows="20" cols="20" id="Message"></textarea>

				<input type="submit" name="submit" value="Submit" class="submit-button" />
			</form>
			
			<div style="clear: both;"></div>
		</div>
	
	</div>

</body>

</html>