#!/bin/bash

. /utils.sh

PWD=`pwd`

pip install --upgrade pip
pip install requests
pip install netaddr
pip install urllib3

cd ipamdealloc

content=$(python deallocinfoipam.py)

print_ext_service_result "$content"



