import requests
import os
import sys

""" Infoblox Settings"""
wapi_version = "2.3.1"
ib_hostname = "10.193.79.250"
ib_user = "admin"
ib_pass = "admin"
""" End Infoblox Settings"""

ip_addr = os.getenv('nicIP_0')

ib_api_endpoint = "https://{}/wapi/v{}".format(ib_hostname, wapi_version)


s = requests.Session()

url = "{}/ipv4address".format(ib_api_endpoint)
print(url)
querystring = {"ip_address": ip_addr}

headers = {}
try:
    #Get the data of the given ip address
    response = s.request("GET", url, headers=headers, params=querystring,
                     verify=False, auth=(ib_user, ib_pass))

    res = response.json()[0]
    if res['status'] == 'UNUSED':
        print("Cannot Delete Unused Ip Address: ", ip_addr)
        sys.exit(10)

    # Delete IP address using reference got from response
    url = "{}/{}".format(ib_api_endpoint, response.json()[0]['_ref'])
    s.request("DELETE", url, verify=False, auth=(ib_user, ib_pass))
except:
    print("Deletion of Ip Address: ",ip_addr," is not successful")
