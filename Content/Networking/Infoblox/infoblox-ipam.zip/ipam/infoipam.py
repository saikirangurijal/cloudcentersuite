import argparse
import requests
import os
import json
import sys
import netaddr
import urllib3

""" Infoblox Settings"""
urllib3.disable_warnings()

wapi_version = "2.3.1"
ib_hostname = "10.193.79.250"
ib_user = "admin"
ib_pass = "admin"
""" Settings"""

# Exclude these networks from ipam. Must match the networkId
exclude_from_ipam = []  # Ex: ['apps-201', 'apps-202']

domain = "test.local"  # Must match domain configured in Infoblox DNS
dns_server_list = "171.70.168.183"
netmask_0="255.255.255.0"
gateway_0="10.193.72.1"
dns_suffix_list = "shyam.cisco.com"
linux_time_zone = "Etc/UTC"

""" End Settings """

#Pulling in information from env vars
try:
    os_type = os.getenv("eNV_osName")
    nic_index = os.getenv("nicIndex")
    hostname = os.getenv('vmName')
    network_id = os.getenv('networkId')

except Exception as err:
    print("Invalid Environment variable: {0}".format(err))
    sys.exit(1)

""" End Infoblox Settings"""
# nic_index = 1
# network_id = 'VM Network'
# hostname = 'abc1454'
s = requests.Session()

ib_api_endpoint = "https://{}/wapi/v{}".format(ib_hostname, wapi_version)

def usedhcp():

    if network_id in exclude_from_ipam:
	use_dhcp = True
    else:
        use_dhcp = False

    if not use_dhcp:
        try:
            ip = allocate_ip()
            content = {'DnsServerList' : dns_server_list,
                    'nicIP_0': str(ip['ip']),
                    'nicDnsServerList_0': dns_server_list,
                    'nicCount': '1',
                    'nicGateway_0':str(ip['gateway']),
                    'nicNetmask_0':ip['netmask'],
                    'domainName':domain,
                    'HwClockUTC':'true',
                    'timeZone':linux_time_zone,
                    'osHostname':hostname}
            return content # Optional:dns_server_list
        except Exception as err:
            print("Allocation of Ip Address is not successful: {0}".format(err))
            sys.exit(1)
    else:
        # Echo key/values back to CloudCenter for VM creation
        content = {'nicCount':1, 'osHostname': hostname, 'nicUseDhcp_0':use_dhcp,'domainName':domain,'HWClockUTC':'true','timeZone':linux_time_zone,'DnsServerList' : dns_server_list,'nicDnsServerList_0': dns_server_list,'nicNetmask_0':netmask_0, 'nicGateway_0':gateway_0}
	return content

def get_ip_addr(ref):
    url = "{}/{}".format(ib_api_endpoint, ref)
    try:
        response = s.request("GET", url, verify=False, auth=(ib_user, ib_pass))
    except Exception as err:
       print("Couldn't create host record: {0}.".format(err))
       sys.exit(1)

    return response.json()['ipv4addrs'][0]['ipv4addr']


def allocate_ip():
    # Get network reference
    url = "{}/network".format(ib_api_endpoint)
    querystring = {
        "*networkId": network_id,
        "_return_fields": "extattrs,network"
    }
    headers = {}
    response = s.request("GET", url, headers=headers, params=querystring, verify=False,
                         auth=(ib_user, ib_pass))
    if len(response.json()) != 1:
        print("Must have exactly one network in Infoblox with "
                      "extensible attribute networkId matching network "
                      "{}. Found {} instead.".format(
                        network_id, len(response.json())
                        ))
        exit(1)
    gateway = response.json()[0]['extattrs']['Gateway']['value']
    subnet = response.json()[0]['network']
    netmask = str(netaddr.IPNetwork(subnet).netmask)

    # Create Host Record
    url = "{}/record:host".format(ib_api_endpoint)
    fqdn = "{hostname}nic{idx}.{domain}".format(hostname=hostname, idx=nic_index, domain=domain)
    payload = {
        "ipv4addrs": [
            {
                "ipv4addr": "func:nextavailableip:{subnet}".format(subnet=subnet)
            }
        ],
        "name": fqdn,
        "configure_for_dns": True
    }
    headers = {'content-type': "application/json"}
    try:
        response = s.request("POST", url, data=json.dumps(payload), headers=headers, verify=False,
                             auth=(ib_user, ib_pass))
        response.raise_for_status()
        host_ref = response.json()
    except Exception as err:
        print("Couldn't create host record: {0}.".format(err))
        sys.exit(1)

    new_ip = get_ip_addr(host_ref)

    return {
        "ip": new_ip,
        "netmask": netmask,
        "gateway": gateway
    }

if __name__ == '__main__':
    print(usedhcp())
