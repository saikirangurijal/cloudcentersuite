import requests
import os
import sys
import json

#Loads configuration file specified in config.json
def load_config(cfg_file='config.json'):
        """

        :cfg_file: configuration file

        """
        with open(
                os.path.join(
                    os.path.abspath(os.path.dirname(__file__)),
                    cfg_file)) as json_file:
            data = json.load(json_file)
            wapi_version = data['wapi_version']
            ib_hostname = data['ib_hostname']
            ib_user = data['ib_user']
            ib_pass = data['ib_pass']
            dic = {'wapi_version':wapi_version,'ib_hostname':ib_hostname,'ib_user':ib_user,'ib_pass':ib_pass}
            return dic


#Get Infoblox Ipam Config Details
dic = load_config()

ip_addr = os.getenv('nicIP_0')

ib_api_endpoint = "https://{}/wapi/v{}".format(dic['ib_hostname'], dic['wapi_version'])

#Creating The Session For Each Request Comes From Workload Manager
s = requests.Session()

url = "{}/ipv4address".format(ib_api_endpoint)
querystring = {"ip_address": ip_addr}
headers = {}

try:
    #Get the data of the given ip address
    response = s.request("GET", url, headers=headers, params=querystring,
                     verify=False, auth=(dic['ib_user'], dic['ib_pass']))

    res = response.json()[0]
    if res['status'] == 'UNUSED':
        print("Cannot Delete Unused Ip Address: ", ip_addr)
        sys.exit(1)

    # Delete IP address using reference parameter got from above response
    url = "{}/{}".format(ib_api_endpoint, response.json()[0]['_ref'])
    s.request("DELETE", url, verify=False, auth=(dic['ib_user'], dic['ib_pass']))
except:
    print("Deletion of Ip Address: ",ip_addr," is not successful")
