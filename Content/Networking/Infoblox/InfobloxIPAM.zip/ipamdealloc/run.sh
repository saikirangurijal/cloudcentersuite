#!/bin/bash

. /utils.sh

#### Shell utility to invoke InfoBlox python libraries

pip install --upgrade pip
pip install requests
pip install netaddr
pip install urllib3

cd ipamdealloc

content=$(python InfobloxDeAlloc.py)

print_ext_service_result "$content"



