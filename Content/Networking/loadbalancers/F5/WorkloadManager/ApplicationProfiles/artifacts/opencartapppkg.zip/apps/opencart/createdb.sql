-- Creates the DB structure
-- cli_installer.php inside the php app creates structure
set global max_connections=400;
set global max_connect_errors=999999;

CREATE DATABASE IF NOT EXISTS opencart;
CREATE USER 'opencart'@'%' IDENTIFIED BY 'opencart';
GRANT ALL PRIVILEGES ON opencart.* TO 'opencart'@'%';

create user 'scalearc'@'%' identified by 'C1sco123!';
create user 'scalearc'@'10.0.0.145' identified by 'C1sco123!';

GRANT UPDATE, SELECT, INSERT, CREATE, DROP, RELOAD, SUPER, REPLICATION SLAVE, REPLICATION CLIENT ON *.* TO 'scalearc'@'%' IDENTIFIED BY 'C1sco123!' WITH GRANT OPTION;
GRANT UPDATE, SELECT, INSERT, CREATE, DROP, RELOAD, SUPER, REPLICATION SLAVE, REPLICATION CLIENT ON *.* TO 'scalearc'@'10.0.0.145' IDENTIFIED BY 'C1sco123!' WITH GRANT OPTION;

