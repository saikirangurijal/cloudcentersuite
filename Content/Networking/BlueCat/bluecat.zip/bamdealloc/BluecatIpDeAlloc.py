
import urllib3
import os
import sys
import json
import requests


urllib3.disable_warnings()

"""
Getting information from the environment
"""

try:
    hostname = os.getenv('vmName')
    network_id =os.getenv('networkId')

except Exception as err:

    sys.exit(1)

"""
Loads configuration file specified in config.json
"""
def load_config(cfg_file='config.json'):
        """
        :cfg_file: configuration file
        """
        with open (
        os.path.join (
            os.path.abspath (os.path.dirname (__file__)),cfg_file)) as json_file:
            data = json.load (json_file)
            bam_hostname = data['bluecat_hostname']
            bam_user = data['bluecat_user']
            bam_pass = data['bluecat_pass']

            dic = {'bam_hostname': bam_hostname, 'bam_user': bam_user, 'bam_pass': bam_pass,
                   }

            return dic

dic = load_config()

ip_addr = os.getenv('nicIP_0')


bam_api_end_point = "http://{}/Services/REST/v1/".format(dic['bam_hostname'])




try:

    login_url = bam_api_end_point + "login?username=" + dic['bam_user'] + "&password=" + dic['bam_pass']


    login_response = requests.get (login_url)
    token = str (login_response.json ())
    token = token.split ()[2] + " " + token.split ()[3]
    header = {'Authorization': token, 'Content-Type': 'application/json'}

except Exception as e:
    print("Login Failed.")
    print(e)

"""
De allocation record with the host name
"""

try:
    logouturl = bam_api_end_point + "logout?"

    records_url=gethostinfo_url=bam_api_end_point+"searchByCategory?"
    records_params={
        "keyword":hostname,
        "category": "RESOURCE_RECORD",
        "start": 0,
        "count": 1
    }

    records_response=requests.get(gethostinfo_url,params=records_params,headers=header)
    records=records_response.json()

    if not records:
        print("Record not found.")
        requests.get(logouturl, headers=header)
        sys.exit(1)

    record=records[0]
    print(record)
    record_id=record['id']


    #Record Deletion
    delete_record_url = bam_api_end_point + "deleteWithOptions?"
    delete_params_data = {
        "objectId":record_id,
        "options": "deleteOrphanedIPAddresses=true|"
    }
    delete_host_response = requests.delete(delete_record_url, params=delete_params_data, headers=header)

    # logout
    logout = requests.get (logouturl, headers=header)

except Exception as er:
    print("IP De allocation failed.",er)
    sys.exit(1)

