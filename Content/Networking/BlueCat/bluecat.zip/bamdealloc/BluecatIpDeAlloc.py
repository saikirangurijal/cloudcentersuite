
import urllib3
import os
import sys
import json
import zeep



urllib3.disable_warnings()

"""
Getting information from the environment
"""

try:
    hostname = os.getenv('vmName')
    network_id =os.getenv('networkId')

except Exception as err:

    sys.exit(1)

"""
Loads configuration file specified in config.json
"""
def load_config(cfg_file='config.json'):
        """
        :cfg_file: configuration file
        """
        with open (
        os.path.join (
            os.path.abspath (os.path.dirname (__file__)),cfg_file)) as json_file:
            data = json.load (json_file)
            bam_hostname = data['bluecat_hostname']
            bam_user = data['bluecat_user']
            bam_pass = data['bluecat_pass']

            dic = {'bam_hostname': bam_hostname, 'bam_user': bam_user, 'bam_pass': bam_pass,
                   }

            return dic



dic = load_config()

ip_addr = os.getenv('nicIP_0')


bam_api_end_point = "http://{}/Services/API?wsdl".format(dic['bam_hostname'])




try:
    client = zeep.Client(bam_api_end_point)


except Exception as e:
    print(e)

try:
    client.service.login(dic['bam_user'], dic['bam_pass'])

except Exception as er:
    print(er)


"""
De allocation record with the host name
"""

try:
    records = client.service.getHostRecordsByHint (0, 1, "hint=" + hostname + "|")
    record_id=records[0].id

    if record_id==0 :
        print("Record not found.")
        client.service.logout ()
        sys.exit(1)

    deletion = client.service.deleteWithOptions(record_id,"deleteOrphanedIPAddresses=true|")

    # logout
    client.service.logout()

except Exception as er:
    print("IP De allocation failed.",er)
    sys.exit(1)

