#!/bin/bash

. /utils.sh
##### warpper shell utility to invoke BlueCat python libraries

pip install --upgrade pip
pip install urllib3
pip install requests

cd bamdealloc

content=$(python BluecatIpDeAlloc.py)
print_ext_service_result "$content"














