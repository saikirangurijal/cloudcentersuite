#!/bin/bash

. /utils.sh
##### warpper shell utility to invoke Bluecat python libraries

pip install --upgrade pip
pip install requests
pip install netaddr
pip install urllib3
apk add --update --no-cache --virtual .build-deps g++ python-dev libxml2  libxml2-dev libxslt-dev
pip install zeep

cd bamdealloc

content=$(python BluecatIpDeAlloc.py)
print_ext_service_result "$content"














