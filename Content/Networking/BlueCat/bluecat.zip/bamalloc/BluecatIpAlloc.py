
import urllib3
import os
import sys
import json
import netaddr
import requests

urllib3.disable_warnings()

#Getting information from the environment

try:
    hostname = os.getenv('vmName')
    network_id =os.getenv('networkId')

except Exception as err:

    sys.exit(1)

#Loads configuration file specified in config.json

def load_config(cfg_file='config.json'):
        """
        :cfg_file: configuration file
        """
        with open (
        os.path.join (
            os.path.abspath (os.path.dirname (__file__)),cfg_file)) as json_file:
            data = json.load (json_file)
            bam_hostname = data['bluecat_hostname']
            bam_user = data['bluecat_user']
            bam_pass = data['bluecat_pass']
            configuration_name = data['configuration_name']
            linux_time_zone = data['linux_time_zone']
            dns_server_list = data['dns_server_list']
            dns_view=data['dns_view']
            dns_zone=data['dns_zone']
            exclude_from_ipam = data['exclude_from_ipam']
            dic = {'bam_hostname': bam_hostname, 'bam_user': bam_user, 'bam_pass': bam_pass,
                   'configuration_name': configuration_name,
                   'linux_time_zone': str (linux_time_zone),'dns_server_list':str(dns_server_list), 'dns_view':dns_view,
                   'dns_zone': dns_zone, 'exclude_from_ipam': exclude_from_ipam}

            return dic


#Retrieving Configuration Properties

dic = load_config()

bam_api_end_point = "http://{}/Services/REST/v1/".format(dic['bam_hostname'])

def usedhcp():

    if network_id in dic['exclude_from_ipam']:

        use_dhcp = True
    else:

        use_dhcp = False

    if not use_dhcp:

        try:
            ip = allocate_ip()

            content = {
                       'nicIP_0': str(ip['ip']),
                       'nicCount': '1',
                       'nicGateway_0':str(ip['gateway']),
                       'DnsServerList': dic['dns_server_list'],
                       'nicNetmask_0':ip['netmask'],
                       'nicDnsServerList_0':dic['dns_server_list'],
                       'domainName': dic['dns_view'],
                       'HwClockUTC': 'true',
                       'timeZone': dic['linux_time_zone'],
                       'osHostname':hostname}

            return content

        except Exception as err:
            print("Allocation of Ip Address is not successful: {0}".format (err))
            sys.exit(1)
    else:
        # Echo key/values back to CloudCenter for VM creation

        content = {'nicCount':1,
                   'osHostname': hostname,
                   'nicUseDhcp_0':use_dhcp,
                   'domainName':dic['dns_view']
                    }

        return content


def allocate_ip():

    # REST API Login and collecting token.
    try:
        login_url = bam_api_end_point + "login?username=" +dic['bam_user'] + "&password=" +dic['bam_pass']

        login_response = requests.get(login_url)
        token = str (login_response.json ())
        token = token.split ()[2] + " " + token.split ()[3]
        header = {'Authorization': token, 'Content-Type': 'application/json'}

    except Exception as e:
        print("Login failed.")
        print(e)


    # Get configuration information
    try:
        logouturl = bam_api_end_point + "logout?"

        getEntityByName = bam_api_end_point + "getEntityByName?parentId=0" \
                          + "&name=" + dic['configuration_name'] + "&type=" + "Configuration"
        Entity_info = requests.get(getEntityByName, headers=header)
        entity_info_response = Entity_info.json()

        config_id = entity_info_response['id']

        if config_id == 0:

            print("{0} named configuration not found.".format(dic['configuration_name']))
            requests.get(logouturl, headers=header)
            sys.exit(1)


        # Getting CIDR Block or Networks information

        block_url = bam_api_end_point + "getEntityByName?parentId=" + str (entity_info_response['id']) \
                    + "&name=" + network_id + "&type=" + "IP4Block"

        main_block_response = requests.get (block_url, headers=header)
        main_block_info_response = main_block_response.json()
        cidr_id = main_block_info_response['id']


        if cidr_id == 0:
            print ("Network block - {0} Not found.".format (cidr_id))
            requests.get (logouturl, headers=header)
            sys.exit(1)

        # getting CIDR block and netmask of a block

        block_cidr = main_block_info_response['properties'].split ('|')[0].split ('=')[1]



        netmask = str (netaddr.IPNetwork (block_cidr).netmask)



        # Finding the next available IP address and gate way in a network

        available_ip_url = bam_api_end_point + "getNextAvailableIP4Address?parentId=" + str (main_block_info_response['id'])
        available_ip_response = requests.get (available_ip_url, headers=header)

        available_ip = available_ip_response.json()

        if available_ip is None :
            print("Network is Full.")
            requests.get (logouturl, headers=header)
            sys.exit(1)


        getIPRangedByIPurl = bam_api_end_point + "getIPRangedByIP?containerId=" + str (
            config_id) + "&type=" + "IP4Network" + "&address=" + available_ip

        ipRangedByIP_response = requests.get (getIPRangedByIPurl,
                                             headers=header)

        ipRangedByIP_response_info = ipRangedByIP_response.json()



        network_prop = ipRangedByIP_response_info['properties']
        gateway_flag = network_prop.find ("Gateway")

        gateway=""

        if (gateway_flag != -1):
            gateway = network_prop.split ('|')[0].split ('=')[1]

        else:
            print ("Custom field 'GateWay' is not found.")
            requests.get(logouturl, headers=header)
            sys.exit(1)


        # Getting view information
        view_info = bam_api_end_point + "getEntityByName?parentId=" + str (entity_info_response['id']) \
                    + "&name=" +dic['dns_view'] + "&type=" + 'View'
        view_inf = requests.get (view_info, headers=header)
        view_inform = view_inf.json()

        if (view_inform['id'] == 0):
            print ("View - {0} not found.".format (dic['dns_view']))
            requests.get(logouturl, headers=header)
            sys.exit(1)

        # adding a host record

        host_recordname = hostname + "." + dic['dns_zone']



        add_host_record_url = bam_api_end_point + "addHostRecord?viewId=" + str (
            view_inform['id']) + "&absoluteName=" + host_recordname + "&addresses=" \
                              + available_ip + "&ttl=" + "-1" + "&properties=" + "reverseRecord=true"

        add_host_record_info = requests.post (add_host_record_url, headers=header)

        if type(add_host_record_info.json()) is not int:
            print ("Record creation failed.")
            print(add_host_record_info.json())
            requests.get (logouturl, headers=header)
            sys.exit(1)

    except Exception as e:
        logouturl = bam_api_end_point + "logout?"
        print(e)
        requests.get(logouturl, headers=header)
        sys.exit(1)


    # logout
    requests.get(logouturl,headers=header)


    return {
        "ip": available_ip,
        "netmask":netmask,
        "gateway":gateway
    }
if __name__ == '__main__':
    print(usedhcp())

