
import urllib3
import os
import sys
import json
import zeep
import netaddr


urllib3.disable_warnings()

#Getting information from the environment

try:
    hostname = os.getenv('vmName')
    network_id =os.getenv('networkId')

except Exception as err:

    sys.exit(1)

#Loads configuration file specified in config.json

def load_config(cfg_file='config.json'):
        """
        :cfg_file: configuration file
        """
        with open (
        os.path.join (
            os.path.abspath (os.path.dirname (__file__)),cfg_file)) as json_file:
            data = json.load (json_file)
            bam_hostname = data['bluecat_hostname']
            bam_user = data['bluecat_user']
            bam_pass = data['bluecat_pass']
            configuration_name = data['configuration_name']
            linux_time_zone = data['linux_time_zone']
            dns_server_list = data['dns_server_list']
            dns_view=data['dns_view']
            dns_zone=data['dns_zone']
            exclude_from_ipam = data['exclude_from_ipam']
            dic = {'bam_hostname': bam_hostname, 'bam_user': bam_user, 'bam_pass': bam_pass,
                   'configuration_name': configuration_name,
                   'linux_time_zone': str (linux_time_zone),'dns_server_list':str(dns_server_list), 'dns_view':dns_view,
                   'dns_zone': dns_zone, 'exclude_from_ipam': exclude_from_ipam}

            return dic


#Retrieving Configuration Properties

dic = load_config()

bam_api_end_point = "http://{}/Services/API?wsdl".format(dic['bam_hostname'])

def usedhcp():

    if network_id in dic['exclude_from_ipam']:

        use_dhcp = True
    else:

        use_dhcp = False

    if not use_dhcp:

        try:
            ip = allocate_ip()

            content = {
                       'nicIP_0': str(ip['ip']),
                       'nicCount': '1',
                       'nicGateway_0':str(ip['gateway']),
                       'DnsServerList': dic['dns_server_list'],
                       'nicNetmask_0':ip['netmask'],
                       'nicDnsServerList_0':dic['dns_server_list'],
                       'domainName': dic['dns_view'],
                       'HwClockUTC': 'true',
                       'timeZone': dic['linux_time_zone'],
                       'osHostname':hostname}

            return content

        except Exception as err:
            print("Allocation of Ip Address is not successful: {0}".format (err))
            sys.exit(1)
    else:
        # Echo key/values back to CloudCenter for VM creation

        content = {'nicCount':1,
                   'osHostname': hostname,
                   'nicUseDhcp_0':use_dhcp,
                   'domainName':dic['dns_view']
                    }

        return content


def allocate_ip():

    # API session
    try:
       client = zeep.Client(bam_api_end_point)

    except Exception as e:
        print("Error in connection")
        print(e)

    # login
    try:
        client.service.login(dic['bam_user'], dic['bam_pass'])

    except Exception as er:
       print("Login failed.")
       print (er)

    # Get configuration information
    try:
        configinfo = client.service.getEntityByName(0, dic['configuration_name'], "Configuration")

        if configinfo.id == 0:

            print("{0} named configuration not found.".format(dic['configuration_name']))
            client.service.logout()
            sys.exit(1)


        # Getting CIDR Block or Networks information
        '''need to do only main block information is enough main name should be taken. Do null check'''

        main_block_info = client.service.getEntityByName (configinfo.id, network_id, "IP4Block")

        cidr_id = main_block_info.id

        if (cidr_id == 0):
            print ("Network block - {0} Not found.".format (cidr_id))
            client.service.logout()
            sys.exit(1)

        # getting CIDR block and netmask of a block

        block_info = client.service.getEntityById(main_block_info.id)

        block_cidr = (block_info.properties).split ('|')[0].split ('=')[1]
        netmask = str (netaddr.IPNetwork (block_cidr).netmask)

        # Finding the next available IP address and gate way in a block or network

        available_ip = client.service.getNextAvailableIP4Address(cidr_id)
        network_range = client.service.getIPRangedByIP(configinfo.id, "IP4Network", available_ip)
        network_prop = network_range.properties

        gateway_flag = network_prop.find ("Gateway")

        if (gateway_flag != -1):
            gateway = network_prop.split ('|')[0].split ('=')[1]
        else:
            print ("Custom field 'GateWay' is not found.")
            client.service.logout()
            sys.exit (1)

        # Getting view information
        '''Need to get the view information from the user and get info on what is view in DNS
               Do null and zero check     
        '''

        view_info = client.service.getEntityByName(configinfo.id, dic['dns_view'], 'View')

        if (view_info.id == 0):
            print ("View - {0} not found.".format (dic['dns_view']))
            client.service.logout ()
            sys.exit(1)

        # adding a host record
        '''Need to identify host record name to be add and zone is important '''

        host_recordname = hostname + "." + dic['dns_zone']
        #print("Host record name is :",host_recordname)
        record = client.service.addHostRecord(view_info.id, host_recordname, available_ip, -1, "reverseRecord=true")
        if record==None:
            print(host_recordname)
            print("record creation failed.")
            sys.exit(1)

    except Exception as e:
        client.service.logout()
        print(e)
        sys.exit(1)


    # logout
    client.service.logout()

    return {
        "ip": available_ip,
        "netmask":netmask,
        "gateway":gateway
    }
if __name__ == '__main__':
    print(usedhcp())

