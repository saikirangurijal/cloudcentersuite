#!/bin/bash

. /utils.sh
##### warpper shell utility to invoke infoblox python libraries

#yum install python-pip

pip install --upgrade pip
pip install requests
pip install netaddr
pip install urllib3
apk add --update --no-cache --virtual .build-deps g++ python-dev libxml2  libxml2-dev libxslt-dev
pip install zeep

cd bamalloc

content=$(python BluecatIpAlloc.py)

print_ext_service_result "$content"
