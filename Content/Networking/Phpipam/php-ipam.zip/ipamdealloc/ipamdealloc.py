from userauth.userauthentication import PHPIpamClient as auth
import requests
import os
import sys

network_id = os.getenv('networkId')
nicIP_0 = os.getenv('nicIP_0')
auth1 = auth()
dic = auth1.getloadfile()
dic1 = auth1.gettokenverify()

#Method to deallocate the ip address in phpipam server
def ipdealloca():

    nwid = getNetwork()
    if not nwid:
        print("Network Not Found In PhpIpam")
        sys.exit(10)
    try:
        data = {'remove_dns': '1'}
        url = "{0}/{1}/{2}/{3}/".format(dic['_api_url'], 'addresses',nicIP_0,nwid)
        res =requests.delete(url, headers=dic1['token'], verify=dic1['verify'],data = data)
        if res.json()['message'] == 'No addresses found':
            print("No Address Found In Phpipam To Delete")
    except:
        print("Request To Delete The Ip Address Is Not Successful")

#Get the network of given networkid
def getNetwork():
    seclis = getSections()
    for id in seclis:
        endpoint = "{0}/{1}/{2}/".format('sections',id,'subnets')
        req = auth1.getcall(endpoint)
        try:
            netinfo = req.json()['data']
            netlis = getSubnet(netinfo)
            if netlis!='':
                return netlis
        except Exception as err:
            print("Retrieving SubnetId From Sections Is Failed: {0}".format(err))
            sys.exit(10)

#Get the all the sections in phpipam
def getSections():
 lis = []
 endpoint = "sections/"
 req = auth1.getcall(endpoint)
 try:
    datalis = req.json()['data']
    for data in datalis:
     lis.append(data['id'])
    return lis
 except Exception as err:
     print("Retrieving Sections From Ipam Server Is Failed: {0}".format(err))
     sys.exit(1)

#Filter the subnet with given networkid
def getSubnet(netinfo):
    if network_id:
        for info in netinfo:
            if info['custom_NetworkId'] == network_id:
                netlis = str(info['id'])
                return netlis
    return ''

if __name__ == '__main__':
    ipdealloca()