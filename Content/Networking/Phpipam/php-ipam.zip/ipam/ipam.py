from userauth.userauthentication import PHPIpamClient as auth

import os
import requests
import netaddr
import sys

#Settings
domain = 'example.com' #Must match exactly with the domain name in phpipam
timeZone = "Etc/UTC"
nicDnsServerList_0 = "171.70.168.183"
DnsServerList = "171.70.168.183"

# Exclude these networks from ipam. Must match the networkId
exclude_from_ipam = []  # Ex: ['apps-201', 'apps-202']

#End Settings

network_id = os.getenv('networkId')
osHostname = os.environ['vmName']

# User Autheticated details
auth1 = auth()
dic1 = auth1.gettokenverify()
dic =auth1.getloadfile()
api_url = dic['_api_url']

#Global variable to assign the subnetid of given networkid
id =''
use_dhcp =''
def usedhcp():
    global use_dhcp
    if network_id in exclude_from_ipam:
        use_dhcp = True
    else:
        use_dhcp = False

    if not use_dhcp:
        try:
            content = ipAllocate()
            return content
        except Exception as err:
            print("Allocation of Ip Address is not successful: {0}".format(err))
            sys.exit(1)
    else:
        # Echo key/values back to CloudCenter for VM creation
        content = {'nicCount': 1, 'osHostname': osHostname, 'nicUseDhcp_0': use_dhcp, 'domainName': domain,
                   'HwClockUTC': 'true', 'timeZone': timeZone, }
        return content


#Call the method to allocate ip and get the gateway address for given network
def ipAllocate():#GET
    try:
        global id
        netlis = getNetwork()

        #If no net network found with given networkid
        if not netlis:
           content  = "Must have exactly one network in PhpIpam with custom field networkId matching network '{}'.".format(network_id)
           return content

        id = netlis[0]
        iplis = getIp()

        content = {"nicUseDhcp_0": use_dhcp,
				   "nicCount":'1',
                   "nicIP_0":iplis[1],
                   "nicGateway_0":netlis[1],
                   "nicNetmask_0":iplis[0],
                   "domainName":domain,
                   "DnsServerList":DnsServerList,
                   "timeZone":timeZone,
                   "HwClockUTC":"true",
                   "osHostname":osHostname}
        return content
    except Exception as err:
        print("Allocation of Ip Address is not successful: {0}".format(err))
        sys.exit(1)

#Get the available Ip address  and Create the Ip address in given networkid
def getIp():
    endpoint = "{0}/{1}/{2}/".format('subnets', id, 'first_free')
    req = auth1.getcall(endpoint)
    return reqCheck(req)

#Check the response of the sent request and process the next step
def reqCheck(req):
    try:
        data = req.json()['data']
        subdata = {"subnetId":id,"ip_addr":data,"hostname":domain}

        #Send post request to create an ip address
        auth1.getpost('addresses',subdata)
        netmask = getMask()
        sublis = [netmask,str(data)]
        return sublis
    except Exception as err:
        print("Creation Of Ip Address Is Failed: {0}".format(err))
        sys.exit(1)


#Get the mask and create netmask for the given networkid
def getMask():
   endpoint = "{0}/{1}/".format('subnets', id)
   req = auth1.getcall(endpoint)
   try:
    data = req.json()['data']
    netmask = str(netaddr.IPNetwork((str(data['subnet'])+'/'+str(data['mask']))).netmask)
    return netmask
   except Exception as err:
       print("NetMask Creation Failed: {0}".format(err))
       sys.exit(1)

#Get the all the sections in phpipam
def getSections():

 lis = []
 endpoint = "sections/"
 req = auth1.getcall(endpoint)
 try:
    datalis = req.json()['data']
    for data in datalis:
     lis.append(data['id'])
    return lis
 except Exception as err:
     print("Retrieving Sections From Ipam Server Is Failed: {0}".format(err))
     sys.exit(1)

#Filter the subnet with given networkid
def getSubnet(netinfo):
    if network_id:
        for info in netinfo:
            if info['custom_NetworkId'] == network_id:
                netlis = [str(info['id']),str(info['custom_Gateway'])]
                return netlis
    return ''

#Get the network of given networkid
def getNetwork():
    seclis = getSections()
    for id in seclis:
        endpoint = "{0}/{1}/{2}/".format('sections',id,'subnets')
        req = auth1.getcall(endpoint)
        try:
            netinfo = req.json()['data']
            netlis = getSubnet(netinfo)
            if netlis!='':
                return netlis
        except Exception as err:
            print("Retrieving SubnetId From Sections Is Failed: {0}".format(err))
            sys.exit(10)

#Send the http post request to the ipam server
def _post(endpoint):
    url = "{0}/{1}".format(api_url, endpoint)
    return requests.post(
        url, headers=dic1["token"], verify=dic1["verify"])

if __name__ == '__main__':
    print(usedhcp())


