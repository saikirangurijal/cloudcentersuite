#!/bin/bash

. /utils.sh

#yum install python-pip
pip install --upgrade pip
pip install requests
pip install netaddr
pip install urllib3
cd ipam
content=$(python ipam.py)
print_ext_service_result "$content"


