#!/bin/bash

. /utils.sh

#### Shell utility to invoke PHP IPAM python libraries
#yum install python-pip

pip install --upgrade pip
pip install requests
pip install netaddr
pip install urllib3

cd ipamdealloc

content= $(python phpIPAMDeAlloc.py)

print_ext_service_result "$content"
