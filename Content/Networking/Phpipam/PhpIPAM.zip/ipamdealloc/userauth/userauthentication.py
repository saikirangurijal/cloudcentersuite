import json
import warnings
import requests
import os
DISABLE_SSL_WARNINGS = True
if DISABLE_SSL_WARNINGS:
    warnings.filterwarnings("ignore")


class PHPIpamClient(object):
    """PHPIPam Python API Client"""

    def __init__(self, cfg_file='config.json'):
        """PPHIpam Python client

        :cfg_file: json configuration file

        """
        self._load_config(cfg_file=cfg_file)
        self._token = None
        self._session = None
        self._auth_session()
        self._verify = False

    def _load_config(self, cfg_file='config.json'):
        """Loads configuration file specified in config.json

        :cfg_file: configuration file

        """
        with open(
                os.path.join(
                    os.path.abspath(os.path.dirname(__file__)),
                    cfg_file)) as json_file:
            data = json.load(json_file)
            self._base_url = data['base_url']
            self._api_name = data['api_name']
            self._auth_url = "{0}/{1}/user/".format(self._base_url,
                                                    self._api_name)
            self._api_url = "{0}/{1}".format(self._base_url, self._api_name)
            self._user = data['user']
            self._passwd = data['passwd']
            dic = {'_base_url':self._base_url,'_api_name':self._api_name,'_auth_url':self._auth_url,'_api_url':self._api_url,}
            return dic

    def _auth_session(self):
        """Authenticates on PHPIpam API

        """
        req = requests.post(
            self._auth_url, auth=(self._user, self._passwd), verify=False)
        if req.status_code != 200:
            raise requests.exceptions.RequestException(
                "Authentication failed on {0}".format(self._auth_url))
        data = req.json()['data']
        self._token = {"token": data['token']}
        return req

    def _call(self, endpoint):
        """Generic requests an endpoint based on API url's

        """
        url = "{0}/{1}".format(self._api_url, endpoint)
        return requests.get(url, headers=self._token, verify=self._verify)

    def _post(self, endpoint, data):
        """Generic posts to an endpoint based on API url's

        """
        url = "{0}/{1}/".format(self._api_url, endpoint)
        return requests.post(
            url, headers=self._token, verify=self._verify, data=data)

    def _put(self, endpoint, data):
        """Generic posts to an endpoint based on API url's

        """
        url = "{0}/{1}".format(self._api_url, endpoint)
        return requests.put(
            url, headers=self._token, verify=self._verify, data=data)

    def getcall(self,endpoint):
        return self._call(endpoint)

    def getpost(self,endpoint,data):
        return self._post(endpoint,data)

    def getput(self,endpoint,data):
        return self._put(endpoint,data)

    def getloadfile(self):
        return self._load_config(cfg_file='config.json')
    def gettokenverify(self):
        dic1 = {"verify":self._verify,"token":self._token}
        return dic1

if __name__ == "__main__":
    PHPIpamClient()