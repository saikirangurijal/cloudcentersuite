#!/bin/bash

. /utils.sh
##### warpper shell utility to invoke infoblox python libraries

#yum install python-pip

pip install --upgrade pip
pip install urllib3
pip install boto3

cd ipam

content=$(python ipamAlloc.py)

if [[ "$content" == N* ]]; then
    print_error "$content"
    exit 127
else
    print_ext_service_result "$content"
fi
