import csv
import os
import json
import boto3
import sys

def loadConfig(cfg_file='config.json'):

    with open(os.path.join(
                    os.path.abspath(os.path.dirname(__file__)),
                    cfg_file)) as json_file:
        data = json.load(json_file)

        filePathList = data['filePath'].split('/')
        fileName = filePathList[-1]

        dic = {'domain':data['domain'],'dns_server_list':data['dns_server_list'],'dns_suffix_list':data['dns_suffix_list'],
               'linux_time_zone':data['linux_time_zone'],'gateway':data['gateway'],'netmask':data['netmask'],'osHostname':data['osHostname'],'nicCount':data['nicCount'],
               'filePath':data['filePath'],'HwClockUTC':data['HwClockUTC'],'ACCESS_KEY':data['ACCESS_KEY'],'SECRET_KEY':data['SECRET_KEY'],
               'region':data['region'],'bucketName':data['bucketName'],'fileName':fileName}
    return dic

dic = loadConfig()
data = ''
try:
    vmName = os.getenv('vmName')
    if not vmName:
        print("No VM Found To Allocate IP")
        sys.exit(0)
except Exception as e:
    print(e)
    sys.exit(0)

def connectS3():

    try:
        # boto3 client configuration
        client = boto3.client('s3', aws_access_key_id=dic["ACCESS_KEY"],aws_secret_access_key=dic["SECRET_KEY"], region_name=dic["region"])
        return client
    except Exception as e:
        print(e)
        sys.exit(0)

def downloadFile():
    try:
        connectS3().download_file(dic['bucketName'],dic['filePath'],dic['fileName'])
    except Exception as e:
        print("Failed To Download The File", dic['fileName'], e)
        sys.exit(0)

def uploadFile():
    try:
        lisGrant = getPolicyBucket()
        connectS3().upload_file(dic['fileName'],dic['bucketName'],dic['filePath'])
        updatePolicy(lisGrant)
    except Exception as e:
        print("Failed To Upload The File",dic['fileName'],e)
        sys.exit(0)

def getPolicyBucket():
    try:
        dicGrant={'READ':'public-read','WRITE':'public-read-write'}
        lisGrant = []
        result = connectS3().get_object_acl(Bucket=dic['bucketName'],Key=dic['filePath'])
        for per in result['Grants']:
            if per['Grantee']['Type'] == 'Group':
                if per['Permission'] == 'READ_ACP' or per['Permission'] == 'WRITE_ACP':
                    continue
                else:
                    lisGrant.append(dicGrant[per['Permission']])
        return lisGrant
    except Exception as e:
        print(e)
        sys.exit(0)

def updatePolicy(lisGrant):
    try:
        if lisGrant:
            client = connectS3()
            for grant in lisGrant:
                client.put_object_acl(Bucket=dic['bucketName'], Key=dic['filePath'], ACL=grant)
    except Exception as e:
        print(e)
        sys.exit(0)

def getAvailableIp():

    downloadFile()

    global data
    try:
        with open(dic['fileName'], 'r') as csvfile:
            # creating a csv reader and writer object
            csvreader = csv.reader(csvfile,delimiter = ",")
            # extracting each data row one by one
            data = list(csvreader)
            tempdata = data
            for row in tempdata:
                if row[1]== 'available':
                    data.remove([row[0], 'available'])
                    data.append([row[0], 'used', vmName])
                    updateIpStatus()
                    return row[0]
            return "0" 

    except Exception as e:
        print("Failed To Read The File",dic['fileName'],e)
        sys.exit(0)

def updateIpStatus():

    try:
        with open(dic['fileName'], 'w') as csvfile:
            # creating a csv reader and writer object
            csvwriter = csv.writer(csvfile,delimiter = ",",lineterminator='\n')
            # extracting each data row one by one
            csvwriter.writerows(data)
        uploadFile()
    except Exception as e:
        print("Failed To Write Content Into A File",e)
        sys.exit(0)


def allocateIp():

    ipaddr = getAvailableIp()

    if ipaddr != '0':
        content = {'nicIP_0': ipaddr,
               'nicDnsServerList_0': str(dic['dns_server_list']),
               'nicCount': str(dic['nicCount']),
               'nicGateway_0': str(dic['gateway']),
               'nicNetmask_0': str(dic['netmask']),
               'domainName': str(dic['domain']),
               'HwClockUTC': 'true',
               'timeZone': str(dic['linux_time_zone']),
               'osHostname': str(dic['osHostname'])}
        return content
    return 'No Free Ip Address Found'

print(allocateIp())
