#!/bin/bash

. /utils.sh

#### Shell utility to invoke InfoBlox python libraries

pip install --upgrade pip
pip install urllib3
pip install requests
pip install scp
pip install paramiko


cd ipamdealloc

content=$(python ipamDealloc.py)

if [[ "$content" == N* ]]; then
    print_error "$content"
    exit 127
else
    print_ext_service_result "$content"
fi



