import csv
import os
import json
import sys
import scp 
import paramiko 

def loadConfig(cfg_file='config.json'):

    with open(os.path.join(
                    os.path.abspath(os.path.dirname(__file__)),
                    cfg_file)) as json_file:
        data = json.load(json_file)

        filePathList = data['filePath'].split('/')
        fileName = filePathList[-1]
        path = ""

        for fpath in filePathList[:-1]:
            path = path + fpath + '/'

        dic = {'repoId':str(data['fileRepositoryIP']),'user':str(data['userName']),'keyPath':str(data['privatekeyFilePath']),'fileName':str(fileName),'path':str(path),'filePath':str(data['pathTOCSVFile'])}
    return dic

dic = loadConfig()
data=''

try:
    vmName = os.getenv('vmName')
    if not vmName:
        print("No VM Found To Allocate IP")
        sys.exit(0)
except Exception as e:
    print(e)
    sys.exit(0)

def downloadFile():
    try:
        ssh = paramiko.SSHClient()
        ssh.load_system_host_keys(filename=dic['keyPath'])
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(dic['repoId'], username=dic['user'], key_filename=dic['keyPath'])

        with scp.SCPClient(ssh.get_transport()) as sc:
            sc.get(dic['filePath'])

    except Exception as e:
        print(e)
        sys.exit(0)

def uploadFile():

    try:
       	ssh = paramiko.SSHClient()
        ssh.load_system_host_keys(filename=dic['keyPath'])
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(dic['repoId'],username=dic['user'],key_filename=dic['keyPath'])
        with scp.SCPClient(ssh.get_transport()) as sc:
            sc.put(dic['fileName'], dic['path'])

    except Exception as e:
        print(e)
        sys.exit(0)

def updateIpStatus():

    try:
        with open(dic['fileName'], 'w') as csvfile:
            # creating a csv reader and writer object
            csvwriter = csv.writer(csvfile,delimiter = ",",lineterminator='\n')
            # extracting each data row one by one
            csvwriter.writerows(data)

        uploadFile()

    except Exception as e:
        print("Failed To Write Content Into A File",e)
        sys.exit(0)


def deallocIp():

    downloadFile()

    global data
    try:
        with open(dic['fileName'], 'r') as csvfile:
            # creating a csv reader and writer object
            csvreader = csv.reader(csvfile,delimiter = ",")
            data = list(csvreader)
            tempdata = data
            # extracting each data row one by one
            for row in tempdata:
                if len(row) == 3:
                    if row[2] == str(vmName):
                        data.remove([row[0], 'used', vmName])
                        data.append([row[0], 'available'])
                        updateIpStatus()
                        return ""
            return "No vmName Found To Deallocate"
    except Exception as e:
        print("Failed To Read The File",dic['fileName'],e)
        sys.exit(0)

deallocIp()
