#!/bin/bash

. /utils.sh
##### warpper shell utility to invoke infoblox python libraries

#yum install python-pip

pip install --upgrade pip
pip install urllib3

#OS - Alpine
apk add --update build-base
apk add gcc libffi-dev python-dev openssl-dev


pip install scp
pip install paramiko

cd ipam

content=$(python ipamAlloc.py)

if [[ "$content" == N* ]]; then
    print_error "$content"
    exit 127
else
    print_ext_service_result "$content"
fi
