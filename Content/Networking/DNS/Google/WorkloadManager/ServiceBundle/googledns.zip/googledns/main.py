#!/usr/bin/env python

# External Life Cycle Action Invocation

from google_dns_client import GoogleDNSClient
import sys
from util import *
from error_utils import ErrorUtils
import json
import os

# Create Google Management Object with credentials
try:
    project_id = os.environ.get("Cloud_Setting_projectName", False)
    google_dns_client = GoogleDNSClient(project_id)
except Exception as aerr:
    write_error(aerr)

    sys.exit(127)
    
except Exception as err:
    write_error(err)
    print_error(ErrorUtils.internal_error(err.message))

    sys.exit(127)

# External Life Cycle Action
# Start - Create subdomain, recordset and assign ip
def start():
    try:
        result = google_dns_client.create()
        print_result(json.dumps(result))
    except Exception as err:
        write_error(err)
        sys.exit(127)

# Stop - Delete subdomain and record set
def stop() :
    try:
        result = google_dns_client.delete()
        print_result(json.dumps(result))
    except Exception as err:
        write_error(err)
        sys.exit(127)
    



