const createHandler = require("azure-function-express").createHandler;
const express = require("express");
const path = require('path');
var bodyParser = require('body-parser');
var session = require('express-session');
var flash = require('req-flash');
const Request = require('tedious').Request;
const Connection = require('tedious').Connection;     
const async = require('async');
var db_username = process.env.dbUsername
var db_pswd = process.env.dbPassword
var server_name = process.env.dbServerName+".database.windows.net"
var db_name = process.env.dbName

// Create connection to database
var config =
{
	authentication: {
		options: {
			userName: db_username, // update me
			password: db_pswd // update me
		},
		type: 'default'
	},
	server: server_name, // update me
	options:
	{
		database: db_name, //update me
		encrypt: true
	}
}
var connection = new Connection(config);

// Create express app as usual
const app = express(); 
 

app.use(express.static(__dirname+'/views' ));
app.set('views', __dirname+'/views' );
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());
app.use(session({
secret: 'djhxcvxfgshajfgjhgsjhfgsakjeauytsdfy',
resave: false,
saveUninitialized: true
}));
app.use(flash());

var _currentData = {};

app.get("/api/home", (req, res) => {
    if (req.query.email || (req.body && req.body.email)) {
        // Add new  
        connection.on('connect', function(err)
        {
            if (err)  {
                res.render('index', { errorMsg: err, successMsg: ''});
                connection.close();
            } else {
                addUser(res, req);
            }           
                    
        });
        
    } else if (req.query.name || (req.body && req.body.name)) {
        // Search user
        connection.on('connect', function(err)
        {
            if (err)  {
                res.render('index', { errorMsg: err, successMsg: ''});
                connection.close(); 
            } else {
                getUser(res, req);    
            }           
                    
        });
    } else {
        connection.on('connect', function(err)
        {
            if (err)  {
                res.render('index', { errorMsg: err, successMsg: ''});
                connection.close(); 
            } else {
                create_table(res,req);    
            }           
                    
        });
        res.render('index', { errorMsg: req.flash('errorMsg'), successMsg: req.flash('successMsg')});
    }
 
});

function create_table(res, req) {

    request = new Request("CREATE TABLE users(username NVARCHAR(128) NOT NULL,email NVARCHAR(128) NOT NULL,  )", function(err) {
        if (err) { 
            res.render('index', { errorMsg: err, successMsg: ''});
        }
    });


    connection.execSql(request);

    
}


function getUser(res, req) {
        var _userList = [];
        request = new Request("SELECT * FROM users WHERE username='"+req.query.name+"';", function(err, rowCount, rows) {
            if (err) res.render('index', { errorMsg: err, successMsg: ''});
        });
         
        var _rows = [];

        request.on("row", columns => {
            var _item = {};
            // Converting the response row to a JSON formatted object: [property]: value
            for (var name in columns) {
                _item['name'] = columns[0].value;
                _item['email'] = columns[1].value; 
            }  
            _rows.push(_item);
            res.render('index', {'users':_rows, 'name': req.query.name});
        }); 
        //res.render('index', {'users':_rows});
        connection.execSql(request);
    }


function addUser(res, req) {

    request = new Request("INSERT INTO [users](username, email) VALUES ('"+req.query.name+"', '"+req.query.email+"');", function(err) {
        if (err) { 
            res.render('index', { errorMsg: err, successMsg: ''});
        }
    });
    request.on("row", columns => {
        req.flash('successMsg', 'User added successfully!');
    });

    res.redirect('/api/home');


    connection.execSql(request);

    
}



app.get("/api/about", (req, res) => {
    res.render('about');
});
   
   
  
// Binds the express app to an Azure Function handler
module.exports = createHandler(app);