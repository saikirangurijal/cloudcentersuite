const createHandler = require("azure-function-express").createHandler;
const express = require("express");
const path = require('path');
var bodyParser = require('body-parser'); 

// Create express app as usual
const app = express(); 
 

app.use(express.static(__dirname));
app.set('views', __dirname );
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());
 

app.get("/api", (req, res) => {
    res.render('index'); 
});

app.get("/api/about", (req, res) => {
    res.render('about');
});
   
   
  
// Binds the express app to an Azure Function handler
module.exports = createHandler(app);