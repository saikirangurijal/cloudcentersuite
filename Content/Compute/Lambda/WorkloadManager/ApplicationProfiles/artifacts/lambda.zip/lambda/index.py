import smtplib
from datetime import datetime

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

message = MIMEMultipart("alternative")
message["Subject"] = "Lambda test"
message["From"] = "testhcl055@gmail.com"
message["To"] = "testhcl055@gmail.com"


def handler(event, context):
    # creates SMTP session
    s = smtplib.SMTP('smtp.gmail.com', 587)

    # start TLS for security
    s.starttls()

    # Authentication
    s.login("testhcl055@gmail.com", "admin@055")

    # message to be sent
    message_content = """\


    AWS Lambda Function triggered. %s

    """ % (datetime.now().strftime('%Y-%m-%d_%H-%M-%S'))

    part = MIMEText(message_content, "plain")

    message.attach(part)
    # sending the mail
    s.sendmail("testhcl055@gmail.com", "testhcl055@gmail.com", message.as_string())

    # terminating the session
    s.quit()



