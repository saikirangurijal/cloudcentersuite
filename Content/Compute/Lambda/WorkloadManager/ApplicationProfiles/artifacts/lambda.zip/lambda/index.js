exports.handler = async (event) => {
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};

Dictionary :

>>> dictionary={'name':'charlie','id':100,'dept':'it'}  
>>> dictionary  
{'dept': 'it', 'name': 'charlie', 'id': 100}  
>>> dictionary.keys()  
['dept', 'name', 'id']  
>>> dictionary.values()  
['it', 'charlie', 100]  



Required params:
	
	iam_role_name = IamRole
	function_name
	runtime(drop down)
	Handler with proper name
	function description
	dynamodb_table_name
	
	deployment package upload location
	
	
	
	
 iamRoleName="LambdaWithDynamoDbStreams"
            functionName ="FinalTest"
            functionDescription="Testing"
            runTime="nodejs8.10"
            handler="lambda/index.handler"
            dynamodbTableName="Users"

	
	

	