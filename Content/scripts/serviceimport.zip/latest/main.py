import urllib3
import json
import sys

JWT = None

ccm_ip = sys.argv[1]
username = sys.argv[2]
password = sys.argv[3]
tenant = sys.argv[4]
service = sys.argv[5]
#external_bundle_location = sys.argv[5]

BASE_URL = "https://%s" % (ccm_ip)
LOGIN_URL = "/suite-auth/login"
SERVICE_URL = "/cloudcenter-ccm-backend/api/v1/tenants/%s/services"

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
http = urllib3.PoolManager()

def login():
    #print BASE_URL
    data = json.dumps({"username": username, "password": password, "tenantName": tenant})
    response = http.request('POST', BASE_URL + LOGIN_URL, body=data, headers={'Content-Type': 'application/json'})
    
    return response

response = login()
if response.status == 200:
    JWT = json.loads(response.data)
    def import_service(url, bundle_path):
        data = {}
        with open(bundle_path, "r") as file:
            data = json.loads(file.read())
            
        response = http.request('POST', url, body=json.dumps(data), headers={'Authorization': "Bearer " + JWT['token'],'Content-Type': 'application/json'})
    
        return response
    #print JWT.get('tenantId', "dfdf") 
    SERVICE_URL = SERVICE_URL % (str(JWT['tenantId']))
    url = BASE_URL + SERVICE_URL

    output = import_service(url, service)
    if output.status == 201:
        result = json.loads(output.data)
        
        if result.get("id", False):
            print "%s Imported Service Successfully" % (result.get("name", ""))
        else:
            print "Failed to import integration unit"

    else:
        print output.data
else:
    print response.status
    print response.data
        
        
        

    




