#!/bin/bash

# Read Username, password , Tenant 
# On successful authentication , Read bundle location and payload in it 
# throw an error in case user does not have API privileges.

function validateIPv4()
{
    local  ip=$1
    local  stat=1

    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
            && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
        stat=$?
    fi
    return $stat
}

function ping_IP() {
   #ping -q -c2 $1 > /dev/null
   arping -D -q -I eth0 -c 2 $1 > /dev/null 2>&1
   if [ $? -eq 1 ]; then
      echo "===> The given IP Address $1 is already used in the network."
      return 1
   else
      return 0            
   fi
}

######################  MAIN STARTS HERE ####################
read -p 'Enter IP Address for Cloud Center Suite: ' ccmIp
while [ 0 -lt 1 ] 
do
   validateIPv4 $ipAddress
   if [[ $? -ne 0 ]]; then
      echo "===> Invalid IP Address: " $ipAddress
      read -p 'Enter IP Address again: ' ipAddress
   else 
      ping_IP $ipAddress
      if [[ $? -eq 0 ]]; then
         break
      else
         read -p 'Enter IP Address again: ' ipAddress
      fi
   fi
done
read -p 'Enter Cloud Center Suite Email Address : ' userEmail
read -p 'Enter the Password : ' password
read -p 'Enter the Tenant ID  : ' tenantId

read -p 'Enter the service JSON location  : ' service
###Install Python Modules ####
#sudo -i 
yum -y update
yum -y install yum-utils
yum -y install https://centos7.iuscommunity.org/ius-release.rpm
yum -y install python-pip
pip install urllib3

python main.py $ccmIp $userEmail $password $tenantId $service

 
