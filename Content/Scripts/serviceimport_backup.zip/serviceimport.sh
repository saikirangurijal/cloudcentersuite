#!/bin/bash

# Read Username, password , Tenant 
# On successful authentication , Read bundle location and payload in it 
# throw an error in case user does not have API privileges.

function isEmailValid() {
      local email=${1}
      local stat=1
      regex="^([A-Za-z]+[A-Za-z0-9]*((\.|\-|\_)?[A-Za-z]+[A-Za-z0-9]*){1,})@(([A-Za-z]+[A-Za-z0-9]*)+((\.|\-|\_)?([A-Za-z]+[A-Za-z0-9]*)+){1,})+\.([A-Za-z]{2,})+"
      if [[ "$email" =~ $regex ]]; then
	stat=$?
      fi
     return $stat
}

######################  MAIN STARTS HERE ####################
read -p 'Enter IP Address for Cloud Center Suite: ' ipAddress

read -p 'Enter Cloud Center Suite Email Address : ' userEmail
while [ 0 -lt 1 ]
do
   isEmailValid $userEmail
   if [[ $? -ne 0 ]]; then
      echo "===> Invalid Email Address: " $userEmail
      read -p 'Enter Email Address again: ' userEmail
   
   else 
	break
   fi
done

#read -p 'Enter the password : ' password
unset password
echo -n "Enter the password: "
while IFS= read -p "$prompt" -r -s -n 1 char
do
    # Enter - accept password
    if [[ $char == $'\0' ]] ; then
        break
    fi
    # Backspace
    if [[ $char == $'\177' ]] ; then
        prompt=$'\b \b'
        password="${password%?}"
    else
        prompt='*'
        password+="$char"
    fi
done
echo ""
read -p 'Enter the Tenant ID  : ' tenantId

cd /ccsworker
PWD=`pwd`
worker=`pwd`
python categoryList.py $ipAddress $userEmail $password $tenantId

serviceZip=""
if [ -f "$PWD/outfile.txt" ]; then 
    serviceZip=`cat outfile.txt`
else
   exit
fi


#serviceBundle=$(find . -maxdepth 1 -type f -name $serviceZip)
unzip -o -q $serviceZip

serviceZIPName=`cat outfile.txt | cut -d'.' -f1`
chmod -R 744 $PWD/$serviceZIPName/*
cd $PWD/$serviceZIPName/iu_bundle

appProfile=$(find . -maxdepth 1 -type f -name "*sample_app.zip" | grep -v "import.zip")
unzip -l $appProfile | grep -q AppProfileTemplateMetaInformation.xml                                                                       
if [ "$?" == "0" ]                                                                     
then                                                                                   
   # Do Nothing 
   echo "The profile bundle is : $appProfile" > /dev/null 2>&1                                             
else                                                                                        
    echo "No valid application profile bundle available. Please download the application integration bundle and extract"
    exit                                                                                                                
fi
#echo "App Profile : $appProfile" 

service=$(find . -maxdepth 1 -type f -name "*_service.json")
#echo "Service JSON : $worker/$service"

logo_path=$(find . -maxdepth 1 -type f -name \*.png -o -name \*.jpg)

if [ -z "$logo_path" ]; then 
  echo "Logo file missing ...."
  echo "Pls provide a logo file for a service with valid extension. Valid extensions are .png or .jpg"
  exit	
fi

#echo "Logo Path: $worker/$logo_path"	
#cp -rf $PWD/* $worker/

cd $worker
if [ -f "$worker/outfile.txt" ]; then
    rm -rf $worker/outfile.txt
fi

#python main.py $ipAddress $userEmail $password $tenantId $service $appProfile $logo_path

python main.py $ipAddress $userEmail $password $tenantId $PWD/$serviceZIPName/iu_bundle/$service $PWD/$serviceZIPName/iu_bundle/$appProfile $PWD/$serviceZIPName/iu_bundle/$logo_path

