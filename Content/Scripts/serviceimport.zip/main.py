
import json
import sys
import os
from os import path
from common import *

service = sys.argv[5]
app_profile = sys.argv[6] 
logo_path = sys.argv[7]

if login():
    ### Repositroy Section Starts #######
    repo_id = 0
    repo_name = ""
    repositories = get_repository()
    
    def print_msg(choice):
        current_path = os.getcwd()
        serviceName = sys.argv[8]
        
        service_bundle = "%s/%s%s" % (current_path, serviceName, '/service_bundle')
        app_bundle = "%s/%s%s" % (current_path, serviceName, '/application_bundle')
        
        serviceList = []
        for service in os.listdir(service_bundle):
            serviceList.append(service_bundle+"/"+service)
            
        service_files = str(", ".join(serviceList))
        appList = []
        for app in os.listdir(app_bundle):
            appList.append(app_bundle+"/"+app)
        app_files = str((", ").join(appList)) 
        
        if choice == 1:
            msg = " 1) Service bundle - %s" % (service_files)
        elif choice == 2:
            msg = " 1) Application bundle - %s" % (app_files)
        elif choice == 3:
            _app_msg = ""
            if bool(app_files):
                _app_msg = "2) Application bundle - %s" % (app_files)
            
            msg = '''1) Service bundle - %s
%s''' % (service_files, _app_msg)
            
        print '''___________________________________________________________________________________________
Please upload the following files to your repo '%s':
%s
Please make sure to change the service bundle path and/or application profile path to reflect your path in the repository.
_____________________________________________________________________________________________''' % (repo_name, msg)
	
    def show_repo(repositories):
        if len(repositories) > 0:
            print "________________________________"
            print "ID	Name of the repository(Type)"
            print "________________________________"
            print "0	exit"
            
            i = 1
            for item in repositories:
                repo_type = " (%s)" % (item.get('type'))
                print str(i) +"	"+item.get('displayName') + repo_type
                i = i + 1 
                
            print ""
            print "Select the repository ID  from the list (press 0 to exit): "
        else:
            print "No Repository"
            sys.exit(127)

    show_repo(repositories)
    input = int(raw_input())
    
    if input > 0 and input <= len(repositories):
        repo_id = repositories[int(input)-1].get('id')
        repo_name = repositories[int(input)-1].get('displayName')
    elif input == 0:
        sys.exit(127)
    else:
        show_repo(repositories)
        
    ##### Repository Section Ends #######

    ##### Service Creation Starts #######

    if repo_id:
        choice = -1
        # App import action
        def app_import_action():
            if path.exists(app_profile):
                app_output = import_app(app_profile, repo_id)
        
                if app_output.get("err"):
                    print "An error occured during import. " + app_output.get('err')
                else:
                    print "Imported Application Profile Successfully"
                    print_msg(choice)
            else:
                print "Application Profile does not exist"

        print "________________________________________________________________"
        print "Select the import option..."
        print "________________________________________________________________"
        selected_service_name = get_service_from_service_list()
        is_service = True
        if selected_service_name:
            is_service = selected_service_name.get("isService", True)
            if is_service:
                logo = import_logo(logo_path)
                data = update_repo_id_payload(repo_id, service, logo)

                print "	1. Import Service Only"
                print "	2. Import Application Profile Only"
                print "	3. Import both Service & Application Profile"
            else:
                print "	1. Import Application Profile"
        # Get depedencies
        dependencies = selected_service_name.get("dependencyTag", False)

        # Check depedency availability
        def has_dependency():
            return bool(dependencies)

        def get_dependent_services(available_services):
            not_available_services = []
            if available_services and dependencies:
                for dependency_service in dependencies:
                    if dependency_service not in available_services:
                        not_available_services.append(dependency_service)

            return not_available_services

        # Display dependencies
        def show_dependencies(dependencies):
            if len(dependencies) == 0:
                return True
                
            print "Checking dependencies..."
            ",".join(dependencies)

            return True
    
        choice = int(raw_input())
        if not is_service:
            app_import_action()
        else:
            if choice == 1:
                result = import_service(data)
                if not result:
                    sys.exit(127)

                if result.get("id", False):
                    print "%s Service imported successfully..." % (result.get("name", ""))
                    print_msg(choice)
                else:
                    print "Failed to import integration unit"
            elif choice == 2:
                try:
                    if has_dependency():
                        available_services = get_all_services()
                        _dependencies = get_dependent_services(available_services)
                        if len(_dependencies) > 0:
                            show_dependencies(_dependencies)
                            print '''The service %s has dependencies with the following services %s
Please import dependent services and retry.''' % (selected_service_name.get("name", ""), ",".join(_dependencies))
                        else:
                            app_import_action()
                    else:
                        app_import_action() 
                except Exception as err:
                    print err.message

            elif choice == 3:
                result = import_service(data)
                if not result:
                    app_import_action()
                    sys.exit(127)

                if result.get("id", False):
                    print "%s Service imported successfully..." % (result.get("name", ""))
                    if has_dependency():
                        available_services = get_all_services()
                        _dependencies = get_dependent_services(available_services)
                        if len(_dependencies) > 0:
                            show_dependencies(_dependencies)
                            print '''The service %s has dependencies with the following services %s
Please import dependent services and retry.''' % (selected_service_name.get("name", ""), ",".join(_dependencies))
                        else:
                            app_import_action()
                    else:
                        app_import_action()
                else:
                    print "Failed to import integration unit"
            else:
                print "Invalid Choice. Please enter a valid choice (1/2/3)"
    ##### Service Creation Ends #########    
    else:
        print "Repository not found." 
else:
    sys.exit(127)
        
