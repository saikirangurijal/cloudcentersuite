import urllib3
import json
import sys
import requests

JWT = None
 
ccm_ip = sys.argv[1]
username = sys.argv[2]
password = sys.argv[3]
tenant = sys.argv[4]
service = sys.argv[5]
app_profile = sys.argv[6] 
logo_path = sys.argv[7]

BASE_URL = "https://%s" % (ccm_ip)
LOGIN_URL = "/suite-auth/login"
SERVICE_URL = "/cloudcenter-ccm-backend/api/v1/tenants/%s/services"
REPO_URL = "/cloudcenter-ccm-backend/api/repositories/" 
APP_URL = "/cloudcenter-ccm-backend/api/apps_portation/import_apps"
LOGO_UPLOAD_URL="/cloudcenter-minio-storage/api/upload/temporary"
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
http = urllib3.PoolManager()

def login():
     
    data = json.dumps({"username": username, "password": password, "tenantName": tenant})
    response = http.request('POST', BASE_URL + LOGIN_URL, body=data, headers={'Content-Type': 'application/json'})
    
    return response

response=None
try:
    response = login()
except urllib3.exceptions.NewConnectionError as connError:
	print "Connection with host can not be established. Verify if host is available"
	sys.exit(127)
except urllib3.exceptions.MaxRetryError as max:
	print "Hostname does not resolve. Please enter a valid host name"
	sys.exit(127)
except Exception as err:
	print "Unknow Error" + err.message
	sys.exit(127)

if response.status == 200:
    JWT = json.loads(response.data)

    #### Getting Repository Information ########
    def get_repository(url): 
        """
        Getting repository information by using get request
        :param url:
        :return:
        """
                
        response = http.request('GET', url, headers={'Authorization': "Bearer " + JWT['token'],'Content-Type': 'multipart/form-data'})
        
        return response


    #### Upload Logo ########
    def import_logo(url, logo_path):
        """
        Uploading logo and getting the temporary path
        :param url:
        :return:
        """
        files = {'file': (logo_path, open(logo_path, 'rb'))}
        res = requests.post(url,  files=files, headers={'Authorization': "Bearer " + JWT['token'], 'x-csrf-token': JWT['csrfToken']},
                            verify=False)
        #print res
        result = json.loads(res.text)

        if result.get("path", False):
            return result.get('path')
        else:
            return 'null'

    #### Replace the extenal bundle action in service paylod #######
    def update_repo_id_payload(repo_id, bundle_path, logo):
        """
        Based on user selection updating the repository in service payload
        :param repo_id:
        :param bundle_path:
        :return:
        """

        data = {}
        with open(bundle_path, "r") as file:
            data = json.loads(file.read())
			
        if data['serviceType'] != "CONTAINER":  
			if data['externalBundleLocation'] != 'null' :
				data['externalBundleLocation'] = "%REPO_ID_"+str(repo_id)+"%"+data['externalBundleLocation']
				data['bundleLocation'] = ""
			elif data['bundleLocation'] != 'null':
				data['bundleLocation'] = "%REPO_ID_" + str(repo_id) + "%" + data['bundleLocation']
				data['externalBundleLocation'] = ""
        data['logoPath'] = logo

        return data

    #### Create Service ########
    def import_service(url, data): 
        """
        Sending request to import service with payload
        :param url:
        :param data:
        :return:
        """
        response = http.request('POST', url, body=json.dumps(data), headers={'Authorization': "Bearer " + JWT['token'],'Content-Type': 'application/json'})
    
        return response
    
    #### Create app profile ########
    def import_app(url, app_profile_path, repo_id): 
        """
        Sending request to import application profile with mapped repository
        :param url:
        :param app_profile_path:
        :param repo_id:
        :return:
        """
        content = None
        with open(app_profile_path , 'rb') as f:
            content =  f.read()         
         
        files = {'file': content}
         
        form_data = [("remap_json", json.dumps([{"type": "RemoteRepository", "oldId": "1", "newId": repo_id}]))]

        res = requests.post( url, data  =form_data , files=files, headers={'Authorization': "Bearer " + JWT['token'], 'x-csrf-token': JWT['csrfToken']}, verify=False)
        print res
        return json.loads(res.text)
    
    ### Repositroy Section Starts #######


    repo_id = 0
    url = BASE_URL + REPO_URL
    repo_output = get_repository(url)
    
    if repo_output.status == 200:
        repo_result = json.loads(repo_output.data)
        repo_items = repo_result.get('repositories') 
        def show_repo(repo_items):
            print "####################################################################"
	    print "All the repositories configured in Workload Manager will be pulled"
	    print "Please ensure that service bundle is uploaded to selected repository before the deployemnt."		
	    print "####################################################################"
	    
            if len(repo_items) > 0:
                print "--------------------------------"
		print "ID  Name of the repository"
		print "--------------------------------"
                print "0   exit"
                
                i = 1
                for item in repo_items:
                    print str(i) +"   "+item.get('displayName')
                    i = i + 1 
		print ""
            	print "Select the repository ID  from the list (press 0 to exit): "

	    else:
                print "No Repository"
                exit()

        show_repo(repo_items)
        input = raw_input()
        
        if input != 0:
            repo_id = repo_items[int(input)-1].get('id')
        elif input == 0:
            exit()
        else:
            show_repo(repo_output)
         
    else:
        print repo_output.status
        print repo_output.data
        
    ##### Repository Section Ends #######

    ##### Service Creation Starts #######

    if repo_id:
        SERVICE_URL = SERVICE_URL % (str(JWT['tenantId']))
        url = BASE_URL + SERVICE_URL
        app_url = BASE_URL + APP_URL

        logo_upload_url = BASE_URL + LOGO_UPLOAD_URL
        logo = import_logo(logo_upload_url, logo_path)
        data = update_repo_id_payload(repo_id, service, logo)
        output = import_service(url, data)
        if output.status == 201:
            result = json.loads(output.data)            
            if result.get("id", False):
                print "%s Service imported successfully..." % (result.get("name", ""))                
                app_output = import_app(app_url, app_profile, repo_id)  
                if app_output.get("err"):
                    print app_output.get('err')
                else:
                    print "Imported Application Profile Successfully"
            else:
                print "Failed to import integration unit"
        else: 
            print output.status
            print output.data

    ##### Service Creation Ends #########    
    
    else:
        print "Repository not found." 
    
else:
    print response.status
    print response.data
        
