#!/bin/bash

# Read Username, password , Tenant 
# On successful authentication , Read bundle location and payload in it 
# throw an error in case user does not have API privileges.



######################  MAIN STARTS HERE ####################
read -p 'Enter IP Address for Cloud Center Suite: ' ipAddress

read -p 'Enter Cloud Center Suite Email Address : ' userEmail

read -p 'Enter the password : ' password
read -p 'Enter the Tenant ID  : ' tenantId

cd /ccsworker
PWD=`pwd`
worker=`pwd`
python categoryList.py

declare serviceZip=""
if [ -f "$PWD/outfile.txt" ]; then 
    serviceZip=`cat outfile.txt`
else
   echo " Cloud not read the service bundle name"
   exit
fi


#serviceBundle=$(find . -maxdepth 1 -type f -name $serviceZip)
unzip -o $serviceZip
serviceZIPName=`cat outfile.txt | cut -d'.' -f1`
cd $PWD/$serviceZIPName/iu_bundle
appProfile=$(find . -maxdepth 1 -type f -name "*sample_app.zip" | grep -v "import.zip")
unzip -l $appProfile | grep -q AppProfileTemplateMetaInformation.xml                                                                       

if [ "$?" == "0" ]                                                                     
then                                                                                   
    echo "The profile bundle is : $appProfile"                                              
else                                                                                        
    echo "No valid application profile bundle available. Please download the application integration bundle and extract"
    exit                                                                                                                
fi

echo "App Profile : $appProfile" 

service=$(find . -maxdepth 1 -type f -name "*_service.json")
echo "Service JSON : $worker/$service"

logo_path=$(find . -maxdepth 1 -type f -name \*.png -o -name \*.jpg)
if [ -z "$logo_path" ]; then 
  echo "Logo file missing ...."
  echo "Pls provide a logo file for a service with valid extension. Valid extensions are .png or .jpg"
  exit	
fi
echo "Logo Path: $worker/$logo_path"	
cp -rf $PWD/$serviceZIPName/iu_bundle/* $worker/
cd $worker
python main.py $ipAddress $userEmail $password $tenantId $service $appProfile $logo_path
