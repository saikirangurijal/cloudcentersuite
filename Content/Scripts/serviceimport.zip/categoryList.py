
import json,os
import requests
import sys
import subprocess

githubUrl = "https://github.com/datacenter/cloudcentersuite/raw/master/Content"

def _decode_list(data):
    rv = []
    for item in data:
        if isinstance(item, unicode):
            item = item.encode('utf-8')
        elif isinstance(item, list):
            item = _decode_list(item)
        elif isinstance(item, dict):
            item = _decode_dict(item)
        rv.append(item)
    return rv

def _decode_dict(data):
    rv = {}
    for key, value in data.iteritems():
        if isinstance(key, unicode):
            key = key.encode('utf-8')
        if isinstance(value, unicode):
            value = value.encode('utf-8')
        elif isinstance(value, list):
            value = _decode_list(value)
        elif isinstance(value, dict):
            value = _decode_dict(value)
        rv[key] = value
    return rv

serviceList=[]
def service_category(execute):
    """
    Function is used to get the services zip file in category vice and stored
    required directory
    :return:
    """
    try:
        path = os.getcwd()
        json_path = path +"/ServiceList.json"
        service_data = json.load(open(json_path, 'r'),object_hook=_decode_dict)
        def categorylist(servicedata):
            """
            Inner function to get the category list from the json
            :param servicedata:
            :return:
            """
            try:
                # print("insdie the function",servicedata)
                # print(type(servicedata))
                if type(servicedata)==list:
                    category = []
                    for data in servicedata:
                        for keys,values in data.iteritems():
                            category.append(keys)
                    category = sorted(set(category))
                    if len(category) > 0:
                        print "--------------------------------"
                        print "ID Name of the Subcateogry "
                        print "--------------------------------"
                        print "0   exit"
                        i = 1
                        for item in category:
                            print str(i) + "   " + item
                            i = i + 1
                        print ""
                        print "Select the Category ID  from the list (press 0 to exit): "
                    else:
                        print "No Repository"
                        sys.exit(127)
                    service_input = int(raw_input())
                    if service_input == 0:
                        sys.exit(127)

                    if service_input > len(category):
                        print "Invalid Choice. Please enter a valid choice."
                        sys.exit(127)

                    count = service_input - 1
                    categorydata = category[count]



                    # print("category details is :",categorydata)
                    categorylist(data[categorydata])

                elif servicedata=="All":
                    services_datas = []
                    def import_all(service_dict):

                        if isinstance(service_dict,dict):
                            for k,v in service_dict.items():
                                if k != "All":
                                    if isinstance(v,list):
                                        import_all(v)
                                        continue
                                    if isinstance(v, dict) and "name" in v:
                                        serviceProcessing(v,execute,True)


                                    else:
                                        import_all(v)
                        elif isinstance(service_dict,list):
                           for data in service_dict:
                                 import_all(data)

                        #count = count +1

                    import_all(service_data)
                    sys.exit(0)
                else:
                    urllist =[]
                    #print("servicedata is outside for loop:",servicedata)
                    try:
                        if servicedata:
                            #print "servicedata is: ",servicedata
                            serviceProcessing(servicedata,execute,False)
                            #f = open('selectedService.json', 'w')
                            #f.write(json.dumps(servicedata))
                            #f.close()
                    except Exception as er:
                        print("Error while writing s file ",er)

                    urllist.append(servicedata["urls"])
                    # print(urllist)
                    downloadFiles(urllist)
            except Exception as er:
                import traceback
                print(traceback.print_exc())
                print("Error while getting category list from the metadata json file {}.",format(er))


        # print(service_data)
        category = []
        for keys,values in service_data.iteritems():

            category.append(keys)
        category = sorted(set(category))
        if len(category) > 0:
            print "--------------------------------"
            print "ID Name of the Category"
            print "--------------------------------"
            print "0   exit"
            i = 1
            for item in category:
                print str(i) + "   " + item
                i = i + 1
            print ""
            print "Select the Category ID  from the list (press 0 to exit): "
        else:
            print "No Repository"
            sys.exit(127)
        service_input = int(raw_input())
        if service_input == 0:
            sys.exit(127)

        if service_input > len(category):
            print "Invalid Choice. Please enter a valid choice."
            sys.exit(127)

        count = service_input - 1
        category_input = category[count]
        # print("categoryinpput is :",category_input)
        subcategory = service_data[category_input]
        # print("subcategory is :",subcategory)
        categorylist(subcategory)

    except Exception as er:
        print(er)

def serviceProcessing(v,execute,all):
    path = os.getcwd()
    zip_path = ""
    service_json = ""
    app_profile = ""
    logo_file = ""
    name = ""

    downloadFiles([v.get('urls')])


    iubundleUrl = v.get('urls', {}).get('serviceLibraryBundle', False)

    if not iubundleUrl:
        sys.exit(127)

    nameZip = iubundleUrl.split("/")[-1]

    subprocess.call(["unzip", "-o", "-q", nameZip])


    name = nameZip.split(".")[0]

    zip_path = path + "/" + name +"/" + "iu_bundle"
    #print v

    if 'isService' in v or 'appProfiles' in v:

        app_profile = path + "/" + name +"/" + "iu_bundle"

        appProfileCount = [f for f in os.listdir(zip_path) if f.endswith('_sample_app.zip')]

        if len(appProfileCount) == 1:
            app_profile = zip_path + "/" + appProfileCount[0]

    if not 'isService' in v:
        service_path = [f for f in os.listdir(zip_path) if f.endswith('_service.json')]
        service_json =""

        if len(service_path) == 0:
            print "Service is missing ..!!!"
        else:
            service_json = zip_path + "/" + service_path[0]

        logo_path = [f for f in os.listdir(zip_path) if f.endswith('.png') or  f.endswith('.jpg')]

        logo_file = ""
        if len(logo_path) == 0:
            print "The Logo file is missing ...!!!!"
        else:
            logo_file = zip_path + "/" + logo_path[0]

        appProfileCount = [f for f in os.listdir(zip_path) if f.endswith('sample_app.zip')]
        if len(appProfileCount) == 1:
            app_profile = zip_path + "/" + appProfileCount[0]

        else:
            print "There is no file in the directory "
    print "\n Importing " + v.get("name", "") + "  ..."
    if all:
        execute(service_json,app_profile,logo_file,name,1,v)
    else:
        execute(service_json,app_profile,logo_file,name,False,v)

def downloadFiles(url_list):
    """
    Function used to download ServiceImport,iu & dockerfile file from github
    :return:
    """
    try:
        #print "Processing.....!!!!!!!!!!!!!!!!!!!! "
        for list in url_list:
            serviceImportUrl = list["serviceImport"]
            dockerFile = list["dockerFile"]
            serviceLibraryBundle = list["serviceLibraryBundle"]

        #print(serviceImportUrl,dockerFile,serviceLibraryBundle)

        serviceImportUrl = githubUrl+"/"+serviceImportUrl

        ### Integration unit bundle
        try:

            iubundleUrl = githubUrl+'/'+serviceLibraryBundle
            name = iubundleUrl.split("/")[-1]
            #servicename = name.replace(".zip", "")
            #if name:
                #print "Services are Downloading started ...!!!!!!!!!!"
                #f = open('outfile.txt', 'a')
                #f.write(name + ",")
                #print "Services are Downloaded Sucessfully ...!!!!!!!!"
                #f.close()

            r = requests.get(url=iubundleUrl)
            with open(name,'wb') as file:
                file.write(r.content)
                    #zip = ZipFile(os.getcwd()+"/"+name,'r')
                    #zip.extractall(os.getcwd()+"/"+name.replace(".zip",""))
        except Exception as er:
            print("Error while downloading IU bundle from github",er)
            sys.exit(127)


    except Exception as Er:
        print("Error while Getting url and downloading file from github",Er)





