import json,os,sys
import requests

githubUrl = "https://github.com/datacenter/cloudcentersuite/raw/master/Content"

def _decode_list(data):
    rv = []
    for item in data:
        if isinstance(item, unicode):
            item = item.encode('utf-8')
        elif isinstance(item, list):
            item = _decode_list(item)
        elif isinstance(item, dict):
            item = _decode_dict(item)
        rv.append(item)
    return rv

def _decode_dict(data):
    rv = {}
    for key, value in data.iteritems():
        if isinstance(key, unicode):
            key = key.encode('utf-8')
        if isinstance(value, unicode):
            value = value.encode('utf-8')
        elif isinstance(value, list):
            value = _decode_list(value)
        elif isinstance(value, dict):
            value = _decode_dict(value)
        rv[key] = value
    return rv

def service_category():
    """
    Function is used to get the services zip file in category vice and stored
    required directory
    :return:
    """
    try:
        path = os.getcwd()
        json_path = path +"/ServiceList.json"
        service_data = json.load(open(json_path, 'r'),object_hook=_decode_dict)

        def categorylist(servicedata):
            """
            Inner function to get the category list from the json
            :param servicedata:
            :return:
            """
            try:
                # print("insdie the function",servicedata)
                # print(type(servicedata))
                if type(servicedata)==list:
                    category = []
                    for data in servicedata:
                        for keys,values in data.iteritems():
                            category.append(keys)
                    category = sorted(set(category))
                    if len(category) > 0:
                        print "--------------------------------"
                        print "ID Name of the Subcateogry "
                        print "--------------------------------"
                        print "0   exit"
                        i = 1
                        for item in category:
                            print str(i) + "   " + item
                            i = i + 1
                        print ""
                        print "Select the Category ID  from the list (press 0 to exit): "
                    else:
                        print "No Repository"
                        exit()
                    input = int(raw_input())
                    if input == 0:
                        exit()
                    count = input - 1
                    categorydata = category[count]
                    # print("category details is :",categorydata)
                    categorylist(data[categorydata])


                else:
                    urllist =[]
                    # print("servicedata is outside for loop:",servicedata)

                    urllist.append(servicedata["urls"])
                    # print(urllist)
                    downloadFiles(urllist)
            except Exception as er:
                print("Error while getting category list from the metadata json file {}.",format(er))


        # print(service_data)
        category = []
        for keys,values in service_data.iteritems():

            category.append(keys)
        category = sorted(set(category))
        if len(category) > 0:
            print "--------------------------------"
            print "ID Name of the Category"
            print "--------------------------------"
            print "0   exit"
            i = 1
            for item in category:
                print str(i) + "   " + item
                i = i + 1
            print ""
            print "Select the Category ID  from the list (press 0 to exit): "
        else:
            print "No Repository"
            exit()
        input = int(raw_input())
        if input == 0:
            exit()
        count = input - 1
        category_input = category[count]
        # print("categoryinpput is :",category_input)
        subcategory = service_data[category_input]
        # print("subcategory is :",subcategory)
        categorylist(subcategory)

    except Exception as er:
        print(er)

def downloadFiles(url_list):
    """
    Function used to download ServiceImport,iu & dockerfile file from github
    :return:
    """
    try:
        for list in url_list:
            serviceImportUrl = list["serviceImport"]
            dockerFile = list["dockerFile"]
            serviceLibraryBundle = list["serviceLibraryBundle"]

        #print(serviceImportUrl,dockerFile,serviceLibraryBundle)

        serviceImportUrl = githubUrl+"/"+serviceImportUrl

        ### Integration unit bundle
        try:
            iubundleUrl = githubUrl+'/'+serviceLibraryBundle
            name = iubundleUrl.split("/")[-1]
            servicename = name.replace(".zip", "")
            if not os.path.exists(servicename):
                os.makedirs(servicename)
            if name:
                f = open('outfile.txt', 'w')
                f.write(name)
                f.close()
                r = requests.get(url=iubundleUrl)
            with open(servicename+"/"+name,'wb') as file:
                file.write(r.content)
                #zip = ZipFile(os.getcwd()+"/"+name,'r')
                #zip.extractall(os.getcwd()+"/"+name.replace(".zip",""))
        except Exception as er:
            print("Error while downloading IU bundle from github",er)
            exit()

    except Exception as Er:
        print("Error while Getting url and downloading file from github",Er)

service_category()