import urllib3
import json
import sys
import requests
import os
from os import path
# JSON Web Token
JWT = None

global ccm_ip, username,password, tenant
# Attributes
ccm_ip = sys.argv[1]
username = sys.argv[2]
password = sys.argv[3]
tenant = sys.argv[4]

# API's
BASE_URL = "https://%s" % (ccm_ip)
LOGIN_URL = "/suite-auth/login"
SERVICE_URL = "/cloudcenter-ccm-backend/api/v1/tenants/%s/services"
REPO_URL = "/cloudcenter-ccm-backend/api/repositories/" 
APP_URL = "/cloudcenter-ccm-backend/api/apps_portation/import_apps"
LOGO_UPLOAD_URL="/cloudcenter-minio-storage/api/upload/temporary"

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
http = urllib3.PoolManager()

# Login
def login():
    global JWT
    if not JWT:
        response = None
        try:
            data = json.dumps({"username": username, "password": password, "tenantName": tenant})
            response = requests.post(BASE_URL + LOGIN_URL, data=data, headers={'Content-Type': 'application/json'},verify=False)
        except requests.exceptions.SSLError as ssl:
            print "Connection with host can not be established. Verify if host is available"
        except Exception as err:
            print err

        if response.status_code  == 404:
            print "Domain page not found. Please enter a valid domain name."
            return False

        if response.status_code  == 200:
            JWT = json.loads(response.text)
            return True
        elif response.status_code == 401:
            print("Authentication Failed: Invalid credentials")
        else:
            err = json.loads(response.text)
            print(err.get("errors", [])[0].get("message", ""))

        return False
    else:
        return True

# Get Service Name from service metadata
def get_service_name(service):
    with open(service, "r") as f:
        _service = json.loads(f.read())
        return _service.get("name")

    return False

#### Get all Repositories########
def get_repository(): 
    """
    Getting repository information by using get request
    :param url:
    :return:
    """
    url = BASE_URL + REPO_URL
    response = requests.get(url, headers={'Authorization': "Bearer " + JWT['token'],'Content-Type': 'multipart/form-data'}, verify=False)
    
    if response.status_code  == 200:
        result = json.loads(response.text)
        return result.get('repositories', []) 

    return []


#### Upload Logo ########
def import_logo(logo_path):
    """
    Uploading logo and getting the temporary path
    :param url:
    :return:
    """
    files = {'file': (logo_path, open(logo_path, 'rb'))}
    url = BASE_URL + LOGO_UPLOAD_URL
    res = requests.post(url,  files=files, headers={'Authorization': "Bearer " + JWT['token'], 'x-csrf-token': JWT['csrfToken']},
                        verify=False)
    #print res
    result = json.loads(res.text)

    if result.get("path", False):
        return result.get('path')
    else:
        return 'null'

#### Replace the extenal bundle action in service paylod #######
def update_repo_id_payload(repo_id, bundle_path, logo):
    """
    Based on user selection updating the repository in service payload
    :param repo_id:
    :param bundle_path:
    :return:
    """

    data = {}
    with open(bundle_path, "r") as file:
        data = json.loads(file.read())
        
    if data['serviceType'] != "CONTAINER":  
        if data['externalBundleLocation'] != 'null' :
            data['externalBundleLocation'] = "%REPO_ID_"+str(repo_id)+"%"+data['externalBundleLocation']
            data['bundleLocation'] = ""
        elif data['bundleLocation'] != 'null':
            data['bundleLocation'] = "%REPO_ID_" + str(repo_id) + "%" + data['bundleLocation']
            data['externalBundleLocation'] = ""
    data['logoPath'] = logo

    return data

#### Create Service ########
def import_service(data): 
    """
    Sending request to import service with payload
    :param url:
    :param data:
    :return:
    """
    import_url = SERVICE_URL % (str(JWT['tenantId']))
    url = BASE_URL + import_url
    response = requests.post(url, data=json.dumps(data), headers={'Authorization': "Bearer " + JWT['token'],'Content-Type': 'application/json'}, verify=False)

    if response.status_code  == 201:
        return json.loads(response.text)
    else:
        err = json.loads(response.text)
        print(err.get("errors", [])[0].get("message", ""))
        
    return False

#### Create app profile ########
def import_app(app_profile_path, repo_id): 
    """
    Sending request to import application profile with mapped repository
    :param url:
    :param app_profile_path:
    :param repo_id:
    :return:
    """
    content = None
    with open(app_profile_path , 'rb') as f:
        content =  f.read()         
        
    files = {'file': content}
        
    form_data = [("remap_json", json.dumps([{"type": "RemoteRepository", "oldId": "1", "newId": repo_id}]))]

    url = BASE_URL + APP_URL
    res = requests.post( url, data  =form_data , files=files, headers={'Authorization': "Bearer " + JWT['token'], 'x-csrf-token': JWT['csrfToken']}, verify=False)
    
    return json.loads(res.text)

def get_all_services():
    """
    Get all service information by using get request
    :param url:
    :return:
    """
    service_names = []

    _service_url = SERVICE_URL % (str(JWT['tenantId']))
    url = BASE_URL + _service_url
    url = url + "?size=100"

    response = requests.get(url, headers={'Authorization': "Bearer " + JWT['token'],'Content-Type': 'multipart/form-data'}, verify=False)
    if response.status_code == 200:
        result = json.loads(response.text)
        services = result.get("services", [])
        
        for service in services:
            service_names.append(service.get("name"))

    return service_names


def get_service_from_service_list(service_name):
    service = {}
    _path = os.getcwd()
    json_path = _path +"/ServiceList.json"
    services = json.load(open(json_path, 'r'))
    for s in services:
        if service_name == s.get("serviceID", 0):
            service = s

    return service

