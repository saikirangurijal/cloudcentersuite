import urllib3
import json
import sys
import requests
import os
from os import path

JWT = None
 
ccm_ip = sys.argv[1]
username = sys.argv[2]
password = sys.argv[3]
tenant = sys.argv[4]
service = sys.argv[5]
app_profile = sys.argv[6] 
logo_path = sys.argv[7]

service_name = ""
with open(service, "r") as f:
    _service = json.loads(f.read())
    service_name = _service.get("name")

BASE_URL = "https://%s" % (ccm_ip)
LOGIN_URL = "/suite-auth/login"
SERVICE_URL = "/cloudcenter-ccm-backend/api/v1/tenants/%s/services"
REPO_URL = "/cloudcenter-ccm-backend/api/repositories/" 
APP_URL = "/cloudcenter-ccm-backend/api/apps_portation/import_apps"
LOGO_UPLOAD_URL="/cloudcenter-minio-storage/api/upload/temporary"
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
http = urllib3.PoolManager()

def login():
     
    data = json.dumps({"username": username, "password": password, "tenantName": tenant})
    response = requests.post(BASE_URL + LOGIN_URL, data=data, headers={'Content-Type': 'application/json'},verify=False)
    
    return response

response=None
try:
    response = login()
except requests.exceptions.SSLError as ssl:
    print "Connection with host can not be established. Verify if host is available"
    sys.exit(127)
except Exception as err:
    print err
    print "Unknow Error" + err.message
    sys.exit(127)

if response.status_code  == 404:
    print "Domain page not found. Please enter a valid domain name."
    sys.exit(127)

if response.status_code  == 200:
    JWT = json.loads(response.text)

    #### Getting Repository Information ########
    def get_repository(url): 
        """
        Getting repository information by using get request
        :param url:
        :return:
        """
                
        response = requests.get(url, headers={'Authorization': "Bearer " + JWT['token'],'Content-Type': 'multipart/form-data'}, verify=False)
        
        return response


    #### Upload Logo ########
    def import_logo(url, logo_path):
        """
        Uploading logo and getting the temporary path
        :param url:
        :return:
        """
        files = {'file': (logo_path, open(logo_path, 'rb'))}
        res = requests.post(url,  files=files, headers={'Authorization': "Bearer " + JWT['token'], 'x-csrf-token': JWT['csrfToken']},
                            verify=False)
        #print res
        result = json.loads(res.text)

        if result.get("path", False):
            return result.get('path')
        else:
            return 'null'

    #### Replace the extenal bundle action in service paylod #######
    def update_repo_id_payload(repo_id, bundle_path, logo):
        """
        Based on user selection updating the repository in service payload
        :param repo_id:
        :param bundle_path:
        :return:
        """

        data = {}
        with open(bundle_path, "r") as file:
            data = json.loads(file.read())
			
        if data['serviceType'] != "CONTAINER":  
			if data['externalBundleLocation'] != 'null' :
				data['externalBundleLocation'] = "%REPO_ID_"+str(repo_id)+"%"+data['externalBundleLocation']
				data['bundleLocation'] = ""
			elif data['bundleLocation'] != 'null':
				data['bundleLocation'] = "%REPO_ID_" + str(repo_id) + "%" + data['bundleLocation']
				data['externalBundleLocation'] = ""
        data['logoPath'] = logo

        return data

    #### Create Service ########
    def import_service(url, data): 
        """
        Sending request to import service with payload
        :param url:
        :param data:
        :return:
        """
        response = requests.post(url, data=json.dumps(data), headers={'Authorization': "Bearer " + JWT['token'],'Content-Type': 'application/json'}, verify=False)
    
        return response
    
    #### Create app profile ########
    def import_app(url, app_profile_path, repo_id): 
        """
        Sending request to import application profile with mapped repository
        :param url:
        :param app_profile_path:
        :param repo_id:
        :return:
        """
        content = None
        with open(app_profile_path , 'rb') as f:
            content =  f.read()         
         
        files = {'file': content}
         
        form_data = [("remap_json", json.dumps([{"type": "RemoteRepository", "oldId": "1", "newId": repo_id}]))]

        res = requests.post( url, data  =form_data , files=files, headers={'Authorization': "Bearer " + JWT['token'], 'x-csrf-token': JWT['csrfToken']}, verify=False)
        print res
        return json.loads(res.text)
    
    ### Repositroy Section Starts #######


    repo_id = 0
    url = BASE_URL + REPO_URL
    repo_output = get_repository(url)
    
    if repo_output.status_code  == 200:
        repo_result = json.loads(repo_output.text)
        repo_items = repo_result.get('repositories') 
        def show_repo(repo_items):
            print "___________________________________________________________________________________________"
	    print "All the repositories configured in Workload Manager will be pulled."
	    print "Please do the following before the deployment."
	    print "	1. Upload the service and application bundle to the selected repository."
	    print "	2. Modify the service and application bundle path in Service and in Application Profile."		
	    print "_____________________________________________________________________________________________"
	    
            if len(repo_items) > 0:
                print "________________________________"
		print "ID	Name of the repository"
		print "________________________________"
                print "0	exit"
                
                i = 1
                for item in repo_items:
                    print str(i) +"	"+item.get('displayName')
                    i = i + 1 
		print ""
            	print "Select the repository ID  from the list (press 0 to exit): "

	    else:
                print "No Repository"
                exit()

        show_repo(repo_items)
        input = raw_input()
        
        if input != 0:
            repo_id = repo_items[int(input)-1].get('id')
        elif input == 0:
            exit()
        else:
            show_repo(repo_output)
         
    else:
        #print repo_output.status
        print repo_output.data
        
    ##### Repository Section Ends #######

    ##### Service Creation Starts #######

    if repo_id:
        SERVICE_URL = SERVICE_URL % (str(JWT['tenantId']))
        url = BASE_URL + SERVICE_URL
        app_url = BASE_URL + APP_URL

        logo_upload_url = BASE_URL + LOGO_UPLOAD_URL
        logo = import_logo(logo_upload_url, logo_path)
        data = update_repo_id_payload(repo_id, service, logo)
        '''output = import_service(url, data)
        if output.status_code  == 201:
            result = json.loads(output.data)            
            if result.get("id", False):
                print "%s Service imported successfully..." % (result.get("name", ""))                
                app_output = import_app(app_url, app_profile, repo_id)  
                if app_output.get("err"):
                    print app_output.get('err')
                else:
                    print "Imported Application Profile Successfully"
            else:
                print "Failed to import integration unit"
        else: 
            print output.status_code 
            print output.text'''

        def app_import_action():
            if path.exists(app_profile):
                app_output = import_app(app_url, app_profile, repo_id)
                if app_output.get("err"):
                    print app_output.get('err')
                else:
                    print "Imported Application Profile Successfully"
            else:
                print "Application Profile does not exist"

        print "________________________________________________________________"
        print "Select the import option..."
	print "________________________________________________________________"

        print "	1. Import Service Only"
        print "	2. Import Application Profile Only"
        print "	3. Import both Service & Application Profile"
        choice = int(raw_input())

        if choice == 1:
            output = import_service(url, data)
            if output.status_code  == 201:
                result = json.loads(output.text)
                if result.get("id", False):
                    print "%s Service imported successfully..." % (result.get("name", ""))
                else:
                    print "Failed to import integration unit"
            else:
                print output.status_code
                print output.text

        elif choice == 2:
            try:
				print "Dependencies: "
				
				_path = os.getcwd()
				json_path = _path +"/ServiceList.json"
				services = json.load(open(json_path, 'r'))
				service = {}
				for s in services:
					if service_name == s.get("serviceID", 0):
						service = s
						
				dependencies = service.get("dependencyTag", False)
                                if dependencies:
				    print ",".join(dependencies)
					
				    print "Do you want to continue(yes/no)"
				    c = str(raw_input()).lower()
				    if c in ["yes", "y"]:
				        app_import_action()

            except Exception as err:
                print err.message

        elif choice == 3:
            output = import_service(url, data)
            if output.status_code  == 201:
                result = json.loads(output.text)
                if result.get("id", False):
                       print "%s Service imported successfully..." % (result.get("name", ""))
                       app_import_action()
                else:
                    print "Failed to import integration unit"
            else:
                print output.status_code
                print output.text
        else:
            print "Invalid Choice. Please enter a valid choice (1/2/3)"


    ##### Service Creation Ends #########    
    
    else:
        print "Repository not found." 
    
else:
    print response.status_code
    print response.text
        
