#!/usr/bin/python
import sys

current_word = None
current_count = 0
word = None
dic={}

# input comes from STDIN
for line in sys.stdin:

    # remove leading and trailing whitespace
    line = line.strip()
    # parse the input we got from mapper.py
    #word, count = line.split('  ',1)
    line = line.split()
    word = line[0]
    count = line[1]

    # convert count (currently a string) to int
    try:
        count = int(count)

    except ValueError:
        # count was not a number, so silently
        # ignore/discard this line
        continue

    # this IF-switch only works because Hadoop sorts map output
    # by key (here: word) before it is passed to the reducer

    try:
        if dic[word]:
            dic[word] += count
            dic.update({word:dic[word]})

    except KeyError :
        current_count = count
        current_word = word
        dic.update({current_word: current_count})

for word, count in dic.items():
                # write the results to standard output STDOUT
                print('%s    %s' % (word, count))  # Emit the word


