<?php
ini_set("display_errors", 1); 
$file = 'wordop.txt';
$errorMsg = "";
if(isset($_POST) && !empty($_POST)) {  
	
	if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['message'])) { 
		$errorMsg = '';
		$name     = $_POST['name'];
		$email    = $_POST['email']; 
		$message = $_POST['message'];     
		$content = "\n".date('d-m-Y, h:i:s').": \n\r".$name."\n\r".$email."\n\r".$message;
		if(file_exists($file)) {
			unlink($file);
			unlink('/var/www/phpsimpleform/word.txt');
			unlink('/var/www/phpsimpleform/part-00000');
		} 	 
		$fp = fopen($file, 'w');
		fwrite($fp, $content);
		fclose($fp);
		chmod($file, 0777); 
		echo "Welcome world!<br>";
		chmod('/var/www/phpsimpleform/validation.sh', 0777);
		echo "Hello world!<br>";
		shell_exec('sudo ./validation.sh');
		echo "Bye world!<br>";
		header('Location: index.php');    
		
	} else {
		$errorMsg = "Please enter name, email and message.";
	}
}
?> 
<html>

<head>
	<title>Simple Contact Form</title>
	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>

	<div id="page-wrap">

		<h1 align="center">Simple Contact Form</h1><br /><br />
				
		<div id="contact-area">
			<?php
			if($errorMsg) echo '<p style="color:red; text-align:center" >'.$errorMsg.'</p>';
			if(file_exists($file)) {
				echo '<h3 style="float:right"><a href="word.txt" style="color:blue"><b>Click here to check hadoop output</b></a></h3><br><br>';
			}
			?>
			<form method="post" action="" name="regForm">
				<label for="Name">Name:</label>
				<input type="text" name="name" id="Name" /> 
	
				<label for="Email">Email:</label>
				<input type="text" name="email" id="Email" />
				
				<label for="Message">Message:</label><br />
				<textarea name="message" rows="20" cols="20" id="Message"></textarea>

				<input type="submit" name="submit" value="Submit" class="submit-button" />
			</form>
			
			<div style="clear: both;"></div>
		</div>
	
	</div>

</body>

</html>
