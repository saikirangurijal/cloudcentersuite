<?php 
$tableName = 'users'; 
$dbname= 'mydb';
$servername = 'localhost';
$username =  'root';
$password ='';


?>


