#!/bin/bash
#Hadoop MultiNode Cluster for linux

 # Logging while running Hadoop service script
 exec > >(tee -a /usr/local/osmosix/logs/service.log) 2>&1

 echo "Executing service script.."
 OSSVC_HOME=/usr/local/osmosix/service

 . /usr/local/osmosix/etc/.osmosix.sh
 . /usr/local/osmosix/etc/userenv
 . $OSSVC_HOME/utils/cfgutil.sh
 . $OSSVC_HOME/utils/install_util.sh
 . $OSSVC_HOME/utils/os_info_util.sh

 # Sourcing variables from service directory

 # RUN EVERYTHING AS ROOT
 if [ "$(id -u)" != "0" ]; then
     exec sudo "$0" "$@"
 fi

source /usr/local/osmosix/etc/userenv

cloudName=`cat /usr/local/osmosix/etc/cloud`

if [ "$cloudName" == 'amazon' ] 
then
	export keyName="cliqr-user-key_1"	
elif [ "$cloudName" == 'azure' ]
then
	export keyName="cliqr-user-key_1"
else
	export keyName="cliqruserKey"
fi

export pubIP='echo $CliqrTier_'$cliqrAppTierName"_IP"
export publicIP=`eval $pubIP`

export ipListName='echo $CliqrTier_'$CliqrDependencies"_IP"
export ipList=`eval $ipListName`

for i in $(echo $ipList | sed "s/,/ /g")
do
   export masterIp=$i
   break

done

su - cliqruser -c "ssh cliqruser@$masterIp 'rm -rf /tmp/wordop.txt' "

su - cliqruser -c "ssh cliqruser@$masterIp '/opt/hadoop/hadoop/bin/hadoop fs -rm -r -f /user/wordop.txt' "

su - cliqruser -c "scp -r -o StrictHostKeyChecking=no -i /home/cliqruser/.ssh/$keyName /var/www/phpsimpleform/wordop.txt cliqruser@$masterIp:/tmp/ "

su - cliqruser -c "ssh cliqruser@$masterIp '/opt/hadoop/hadoop/bin/hdfs dfs -put /tmp/wordop.txt   /user' "

su - cliqruser -c "ssh cliqruser@$masterIp 'mkdir /tmp/pythonvalid' "

chmod 755 /var/www/phpsimpleform/mapper.py

chmod 755 /var/www/phpsimpleform/reducer.py

su - cliqruser -c "scp -r -o StrictHostKeyChecking=no -i /home/cliqruser/.ssh/$keyName /var/www/phpsimpleform/mapper.py /var/www/phpsimpleform/reducer.py  cliqruser@$masterIp:/tmp/pythonvalid/ "

cat  /usr/local/osmosix/etc/userenv > env.txt

if [ -f '/opt/.count' ]; then
	cat >> /opt/.count <<EOL

EOL
else
	cat > /opt/.count <<EOL
export loopcount=0
EOL

fi

source  /opt/.count
export loopcount1='echo $loopcount'
export loopcount=`eval $loopcount1`

export count1='echo $count'
export count=`eval $count1`

if [[ "$loopcount" == 0 ]]; then
	export fileName="WordCount"
	export count=0
else
	export fileName="WordCount""$count"
fi
countloop=$(($count+1))
	cat > /opt/.count <<EOL
export count=$countloop
EOL



	
su - cliqruser -c "ssh cliqruser@$masterIp '/opt/hadoop/hadoop/bin/hadoop jar /opt/hadoop/hadoop/share/hadoop/tools/lib/hadoop-streaming-3.2.0.jar -file /tmp/pythonvalid/mapper.py -mapper /tmp/pythonvalid/mapper.py -file   /tmp/pythonvalid/reducer.py -reducer /tmp/pythonvalid/reducer.py -input /user/wordop.txt -output /user/$fileName' "


	cat > /var/www/phpsimpleform/word.txt <<EOL
******************** Hadoop Connection Status : OPened ********************

Fetching data :
EOL

cat  /var/www/phpsimpleform/wordop.txt >> word.txt

su - cliqruser -c "ssh cliqruser@$masterIp '/opt/hadoop/hadoop/bin/hdfs dfs -get /user/$fileName /tmp' "

chown cliqruser:cliqruser /var/www/phpsimpleform
chown cliqruser:cliqruser /var/www/phpsimpleform/*


export scp="scp -r -o StrictHostKeyChecking=no -i /home/cliqruser/.ssh/$keyName /tmp/$fileName/part-00000  cliqruser@$publicIP:/var/www/phpsimpleform"

su - cliqruser -c "ssh cliqruser@$masterIp '$scp' "

if [ -f "/var/www/phpsimpleform/part-00000" ]; then
	cat >> /var/www/phpsimpleform/word.txt <<EOL
	
Stored Data In Hadoop Successfully
EOL

else
	cat >> /var/www/phpsimpleform/word.txt <<EOL
	
Failed To Store Data In Hadoop
EOL

fi
	
chown cliqruser:cliqruser /var/www/phpsimpleform/*

	cat >> /var/www/phpsimpleform/word.txt <<EOL

******************** Hadoop Connection Status : Closed ********************

EOL

chown apache:apache /var/www/phpsimpleform/
chown apache:apache /var/www/phpsimpleform/*
