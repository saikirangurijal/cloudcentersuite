#!/bin/bash


#source /usr/local/osmosix/etc/userenv


function empty
{
    local var="$1"

    # Return true if:
    # 1.    var is a null string ("" as empty string)
    # 2.    a non set variable is passed
    # 3.    a declared variable or array but without a value is passed
    # 4.    an empty array is passed
    if test -z "$var"
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is zero (0 as an integer or "0" as a string)
    elif [ "$var" == 0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is 0.0 (0 as a float)
    elif [ "$var" == 0.0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return
    fi

    [[ $( echo "" ) ]]
}


if empty "${cliqrWebappContext}"
    then
       echo "There is no WebContext"
    else
       echo " Web Context Exist $cliqrWebappContext"
fi



if empty "${cliqrWebappConfigFiles}"
    then
       echo "There is no Config Files to Parase"
    else
       echo " Config File exist on $cliqrWebappConfigFiles path"
fi




tomcat_jdbc="/usr/local/tomcat7/webapps/$cliqrWebappContext/$cliqrWebappConfigFiles"

if empty "${CliqrDependencies}"
 then
        echo "Dependency Variable is Empty. No further Process."
 else

                echo "Dependencies variable has valid Value"
                Tier_Arr=$(echo $CliqrDependencies | tr "," "\n")
                for tier  in $Tier_Arr
                do
                        HOST_IP="CliqrTier_${tier}_IP"
			PORT="27011"
			DBNAME_TIER="CliqrTier_${tier}_DBNAME"
			dbName_tier="${dbName}"
			dbname_tier="CliqrTier_${tier}_dbname"
                        echo $HOST_IP
                        
			names_arr=($(echo ${!HOST_IP} | sed "s/,/ /g"))
                        nodeCount="${#names_arr[@]}"
                        i=$(expr "$nodeCount" - 1)
                        
			HOST_TIER_IP="${names_arr[$i]}"
                        #HOST_TIER_IP=${!HOST_IP}
			DBNAME=${!DBNAME_TIER}
			dbName=${!dbName_tier}
			
                        						
                        sed -i  's/^mongo.host/#mongo.host/g'  $tomcat_jdbc
						sed -i  's/^mongo.name/#mongo.name/g'  $tomcat_jdbc 
						sed -i  's/^mongo.port/#mongo.port/g'  $tomcat_jdbc  
						
                        echo "mongo.host=${HOST_TIER_IP}" >> $tomcat_jdbc
			echo "mongo.name=mongodb-cluster" >> $tomcat_jdbc
			echo "mongo.port=${PORT}" >> $tomcat_jdbc 
						
                        echo "export mongoDBHost=$HOST_TIER_IP"  >> /usr/local/osmosix/etc/userenv
			echo "export mongoDBDatabaseName=mydb"  >> /usr/local/osmosix/etc/userenv
			echo "export mongoDBPort=$PORT"  >> /usr/local/osmosix/etc/userenv
			echo "export mongoDbName=$dbName"  >> /usr/local/osmosix/etc/userenv
			echo "export mongoDBNAME=$DBNAME"  >> /usr/local/osmosix/etc/userenv
			echo "export mongodbname=$dbname"  >> /usr/local/osmosix/etc/userenv



						
                done
				
				
			
fi




