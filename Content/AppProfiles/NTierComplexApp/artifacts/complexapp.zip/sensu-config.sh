source /usr/local/osmosix/etc/userenv

function emptyCheck
{
    local var="$1"

    # Return true if:
    # 1.    var is a null string ("" as empty string)
    # 2.    a non set variable is passed
    # 3.    a declared variable or array but without a value is passed
    # 4.    an empty array is passed
    if test -z "$var"
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is zero (0 as an integer or "0" as a string)
    elif [ "$var" == 0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is 0.0 (0 as a float)
    elif [ "$var" == 0.0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return
    fi

    [[ $( echo "" ) ]]
}

assignValues(){

		if [[ $1 =~ .*sensu.* ]] 
		then
			CliqrTier_sensu_IP=$2
			echo "export CliqrTier_sensu_IP=$CliqrTier_sensu_IP"  >> /usr/local/osmosix/etc/userenv
		else
			echo "Sorry. Not found."
		fi

}

source /usr/local/osmosix/etc/userenv

if emptyCheck "${CliqrDependencies}"
 then
        echo "Dependency Variable is Empty. No further Process."
 else

                echo "Dependencies variable has valid Value"
                Tier_Arr=$(echo $CliqrDependencies | tr "," "\n")
                for tier  in $Tier_Arr
                do
                        TIER_IP_NAME="CliqrTier_${tier}_IP"
                        echo $TIER_IP_NAME
                        TIER_IP_VALUE=${!TIER_IP_NAME}
		        echo $TIER_IP_VALUE

			if emptyCheck "${TIER_IP_VALUE}"
			then
                            echo " There is no such variable found 	${TIER_IP_VALUE} "
			else
  		   	    echo "export $TIER_IP_NAME=$TIER_IP_VALUE"  >> /usr/local/osmosix/etc/userenv
			    assignValues $TIER_IP_NAME $TIER_IP_VALUE
			fi						
						
                done

fi

source /usr/local/osmosix/etc/userenv

### Sensu Connectivity using IP Address 

if emptyCheck "${CliqrTier_sensu_IP}"
    then
       echo "There is no Sensu Server IP found "
    else
       echo "Found Sensu Server details"
           export sensuServerHost=$CliqrTier_sensu_IP
           export rabbitmqPort=5672
           export sensuServerUserName=sensu
           export sensuServerPassword=secret
           echo "export sensuServerUserName=sensu" >> /usr/local/osmosix/etc/userenv
           echo "export sensuServerPassword=secret" >> /usr/local/osmosix/etc/userenv
           echo "export sensuServerHost=$CliqrTier_sensu_IP" >> /usr/local/osmosix/etc/userenv
           echo "export rabbitmqPort=5672" >> /usr/local/osmosix/etc/userenv
fi
