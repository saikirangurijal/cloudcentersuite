#!/bin/sh

sudo yum -y install wget
sudo yum -y install unzip
source /usr/local/osmosix/etc/userenv

function emptyCheck
{
    local var="$1"

    # Return true if:
    # 1.    var is a null string ("" as empty string)
    # 2.    a non set variable is passed
    # 3.    a declared variable or array but without a value is passed
    # 4.    an empty array is passed
    if test -z "$var"
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is zero (0 as an integer or "0" as a string)
    elif [ "$var" == 0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is 0.0 (0 as a float)
    elif [ "$var" == 0.0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return
    fi

    [[ $( echo "" ) ]]
}

assignValues(){


		if [[ $1 =~ .*MemCache.* ]] 
		then
			CliqrTier_MemCache_IP=$2
			echo "export CliqrTier_MemCache_IP=$CliqrTier_MemCache_IP"  >> /usr/local/osmosix/etc/userenv
		else
			echo "Sorry. Not found."
		fi
		
		if [[ $1 =~ .*MsgBus.* ]] 
		then
			CliqrTier_MsgBus_IP=$2
			echo "export CliqrTier_MsgBus_IP=$CliqrTier_MsgBus_IP"  >> /usr/local/osmosix/etc/userenv
		else
			echo "Sorry. Not found."
		fi

		if [[ $1 =~ .*sensu.* ]] 
		then
			CliqrTier_sensu_IP=$2
			echo "export CliqrTier_sensu_3_IP=$CliqrTier_sensu_IP"  >> /usr/local/osmosix/etc/userenv
		else
			echo "Sorry. Not found."
		fi

}

source /usr/local/osmosix/etc/userenv

if emptyCheck "${CliqrDependencies}"
 then
        echo "Dependency Variable is Empty. No further Process."
 else

                echo "Dependencies variable has valid Value"
                Tier_Arr=$(echo $CliqrDependencies | tr "," "\n")
                for tier  in $Tier_Arr
                do
                        TIER_IP_NAME="CliqrTier_${tier}_IP"
                          echo $TIER_IP_NAME
                        TIER_IP_VALUE=${!TIER_IP_NAME}
						  echo $TIER_IP_VALUE

						if emptyCheck "${TIER_IP_VALUE}"
						 then
                            echo " There is no such variable found 	${TIER_IP_VALUE} "
						 else
  					   	    echo "export $TIER_IP_NAME=$TIER_IP_VALUE"  >> /usr/local/osmosix/etc/userenv
							assignValues $TIER_IP_NAME $TIER_IP_VALUE
						fi						
						
						
                        TIER_HOST_NAME="CliqrTier_${tier}_HOSTNAME"
                          echo $TIER_HOST_NAME
                        TIER_HOST_VALUE=${!TIER_HOST_NAME}
						  echo $TIER_HOST_VALUE
						
						if emptyCheck "${TIER_HOST_VALUE}"
						 then
                            echo " There is no such variable found 	${TIER_HOST_VALUE} "
						 else
							echo "export $TIER_HOST_NAME=$TIER_HOST_VALUE"  >> /usr/local/osmosix/etc/userenv
							assignValues $TIER_HOST_NAME  $TIER_HOST_VALUE
						fi						
						
                done

fi

### Tomcat JSP upgrade

if [ $(ls -la /usr/local/tomcat8 | grep "webapps" | wc -l) -ge 1 ]
    then
       echo "Tomcat upgrade done"
    else
       echo "Tomcat upgrade to be done"
           rm -rf /usr/local/tomcat7/lib/el-api.jar
       cd /tmp
       wget https://www-eu.apache.org/dist/tomcat/tomcat-9/v9.0.16/bin/apache-tomcat-9.0.16.tar.gz
       tar -xf apache-tomcat-9.0.16.tar.gz
       chmod -R 755 apache-tomcat-9.0.16.tar.gz
       mv  apache-tomcat-9.0.16 /usr/local/tomcat8
       chmod -R 755 /usr/local/tomcat8
       rm -rf /usr/local/tomcat8/webapps/ROOT
       cp /usr/local/apache-tomcat-7.0.59/webapps/ROOT  /usr/local/tomcat8/webapps/ -rf
       rm /usr/local/tomcat7 -rf
       ln -s /usr/local/tomcat8 /usr/local/tomcat7
       chown -R cliqruser:cliqruser  /usr/local/tomcat8
       echo "export JAVA_HOME=/usr/lib/jvm/java-8-sun" >> /usr/local/osmosix/etc/userenv
       echo "export JRE_HOME=/usr/lib/jvm/java-8-sun" >> /usr/local/osmosix/etc/userenv

fi

### Sensu Connectivity using IP Address 

if emptyCheck "${CliqrTier_sensu_3_IP}"
    then
       echo "There is no Sensu Server IP found "
    else
       echo "Found Sensu Server details"
           export sensuServerHost=$CliqrTier_sensu_3_IP
           export rabbitmqPort=5672
           export sensuServerUserName=sensu
           export sensuServerPassword=secret
           echo "export sensuServerUserName=sensu" >> /usr/local/osmosix/etc/userenv
           echo "export sensuServerPassword=secret" >> /usr/local/osmosix/etc/userenv
           echo "export sensuServerHost=$CliqrTier_sensu_3_IP" >> /usr/local/osmosix/etc/userenv
           echo "export rabbitmqPort=5672" >> /usr/local/osmosix/etc/userenv
fi
### Sensu Connectivity using Hostname 
if emptyCheck "${CliqrTier_sensu_3_HOSTNAME}"
    then
       echo "There is no Sensu Server Host name found "
    else
       echo "Found Sensu Server details"
           export sensuServerHost=$CliqrTier_sensu_3_HOSTNAME
           export rabbitmqPort=5672
           export sensuServerUserName=sensu
           export sensuServerPassword=secret
           echo "export sensuServerUserName=sensu" >> /usr/local/osmosix/etc/userenv
           echo "export sensuServerPassword=secret" >> /usr/local/osmosix/etc/userenv
           echo "export sensuServerHost=$CliqrTier_sensu_3_HOSTNAME" >> /usr/local/osmosix/etc/userenv
           echo "export rabbitmqPort=5672" >> /usr/local/osmosix/etc/userenv
fi


