#!/bin/bash

source /usr/local/osmosix/etc/userenv
tier="CliqrTier_${CliqrDependencies}_IP"
echo "Tier Name : $tier "
echo "Tier IP : ${!tier} "
tier_port=7005
tier_ip_with_port="${!tier}:${tier_port}"
echo "Tier IP with Port  : $tier_ip_with_port"
sed -i "s,:7005,,g" /etc/nginx/sites-available/default
sed -i "s,${!tier},$tier_ip_with_port,g" /etc/nginx/sites-available/default

