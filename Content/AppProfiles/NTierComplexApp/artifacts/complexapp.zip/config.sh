#!/bin/sh

sudo yum -y install wget
sudo yum -y install unzip
source /usr/local/osmosix/etc/userenv
t_version="8.5.0"


function empty
{
    local var="$1"

    # Return true if:
    # 1.    var is a null string ("" as empty string)
    # 2.    a non set variable is passed
    # 3.    a declared variable or array but without a value is passed
    # 4.    an empty array is passed
    if test -z "$var"
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is zero (0 as an integer or "0" as a string)
    elif [ "$var" == 0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return

    # Return true if var is 0.0 (0 as a float)
    elif [ "$var" == 0.0 2> /dev/null ]
    then
        [[ $( echo "1" ) ]]
        return
    fi

    [[ $( echo "" ) ]]
}



if [ $(ls -la /usr/local/tomcat7upgrade | grep "webapps" | wc -l) -ge 1 ]
    then
       echo "Tomcat upgrade done"
    else
       echo "Tomcat upgrade to be done"
           rm -rf /usr/local/tomcat7/lib/el-api.jar
       cd /tmp
       wget  https://archive.apache.org/dist/tomcat/tomcat-8/v${t_version}/bin/apache-tomcat-${t_version}.tar.gz 
       chmod -R 755 apache-tomcat-${t_version}.tar.gz
       tar -zxvf apache-tomcat-${t_version}.tar.gz
       if [ $(ls -la "/tmp/apache-tomcat-${t_version}.tar.gz"  |  wc -l) -ge 1 ]
       then
           echo "upgrade version downloaded successfully" 
           mv  apache-tomcat-${t_version} /usr/local/tomcat7upgrade
           chmod -R 755 /usr/local/tomcat7upgrade
           rm -rf /usr/local/tomcat7upgrade/webapps/ROOT
           cp /usr/local/apache-tomcat-7.0.59/webapps/ROOT  /usr/local/tomcat7upgrade/webapps/ -rf
           rm /usr/local/tomcat7 -rf
           ln -s /usr/local/tomcat7upgrade /usr/local/tomcat7
           chown -R cliqruser:cliqruser  /usr/local/tomcat7upgrade
           echo "export JAVA_HOME=/usr/lib/jvm/java-8-sun" >> /usr/local/osmosix/etc/userenv
           echo "export JRE_HOME=/usr/lib/jvm/java-8-sun" >> /usr/local/osmosix/etc/userenv
       else
           echo "upgrade failed"
       fi

fi


if empty "${CliqrTier_sensu_3_IP}"
    then
       echo "There is no Sensu Server IP found "
    else
       echo "Found Sensu Server details"
	   export sensuServerHost=$CliqrTier_sensu_3_IP
	   export rabbitmqPort=5672
	   export sensuServerUserName=sensu
	   export sensuServerPassword=secret
	   echo "export sensuServerUserName=sensu" >> /usr/local/osmosix/etc/userenv
	   echo "export sensuServerPassword=secret" >> /usr/local/osmosix/etc/userenv
	   echo "export sensuServerHost=$CliqrTier_sensu_3_IP" >> /usr/local/osmosix/etc/userenv
	   echo "export rabbitmqPort=5672" >> /usr/local/osmosix/etc/userenv
fi





